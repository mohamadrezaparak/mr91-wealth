package com.mr91.wealth.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class JalaliCalendarTest {

    private fun greg(y: Int, m: Int, d: Int): Long = LocalDate.of(y, m, d).toEpochDay()

    @Test
    fun convertsKnownNowruzDates() {
        assertEquals(JalaliDate(1400, 1, 1), JalaliCalendar.fromEpochDay(greg(2021, 3, 21)))
        assertEquals(JalaliDate(1402, 1, 1), JalaliCalendar.fromEpochDay(greg(2023, 3, 21)))
        assertEquals(JalaliDate(1403, 1, 1), JalaliCalendar.fromEpochDay(greg(2024, 3, 20)))
        assertEquals(JalaliDate(1404, 1, 1), JalaliCalendar.fromEpochDay(greg(2025, 3, 21)))
        assertEquals(JalaliDate(1403, 12, 30), JalaliCalendar.fromEpochDay(greg(2025, 3, 20)))
    }

    @Test
    fun knowsLeapYears() {
        assertTrue(JalaliCalendar.isLeapYear(1399))
        assertTrue(JalaliCalendar.isLeapYear(1403))
        assertFalse(JalaliCalendar.isLeapYear(1402))
        assertFalse(JalaliCalendar.isLeapYear(1404))
    }

    @Test
    fun roundTripsEveryDayInRange() {
        var day = greg(2000, 1, 1)
        val end = greg(2045, 12, 31)
        while (day <= end) {
            val jalali = JalaliCalendar.fromEpochDay(day)
            assertTrue("invalid $jalali for day $day", JalaliCalendar.isValid(jalali))
            assertEquals(day, JalaliCalendar.toEpochDay(jalali))
            day++
        }
    }

    @Test
    fun validatesDaysAndLeapEndOfYear() {
        assertTrue(JalaliCalendar.isValid(JalaliDate(1403, 12, 30)))
        assertFalse(JalaliCalendar.isValid(JalaliDate(1403, 12, 31)))
        assertFalse(JalaliCalendar.isValid(JalaliDate(1404, 12, 30)))
        assertFalse(JalaliCalendar.isValid(JalaliDate(1404, 13, 1)))
        assertFalse(JalaliCalendar.isValid(JalaliDate(1404, 7, 0)))
        assertFalse(JalaliCalendar.isValid(JalaliDate(1404, 7, 31)))
    }

    @Test
    fun parsesPersianAndAsciiText() {
        assertEquals(JalaliDate(1403, 7, 15), JalaliCalendar.parse("۱۴۰۳/۰۷/۱۵"))
        assertEquals(JalaliDate(1403, 7, 15), JalaliCalendar.parse("1403-7-15"))
        assertNull(JalaliCalendar.parse("1404/12/30"))
        assertNull(JalaliCalendar.parse("1403/12/31"))
        assertNull(JalaliCalendar.parse("abc"))
        assertNull(JalaliCalendar.parse("1403/07"))
    }

    @Test
    fun formatsWithZeroPadding() {
        assertEquals("1400/01/01", JalaliCalendar.format(greg(2021, 3, 21), persianDigits = false))
        assertEquals("۱۴۰۰/۰۱/۰۱", JalaliCalendar.format(greg(2021, 3, 21), persianDigits = true))
    }
}
