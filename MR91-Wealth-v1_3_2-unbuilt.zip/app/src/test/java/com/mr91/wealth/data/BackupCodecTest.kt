package com.mr91.wealth.data

import com.mr91.wealth.data.BackupException.Code
import org.junit.Assert.assertEquals
import org.junit.Assert.fail
import org.junit.Test

class BackupCodecTest {

    private fun sample(): BackupSnapshot = BackupSnapshot(
        accounts = listOf(Account("cash", "نقد", AccountType.CASH, openingMinor = 1_000, createdAt = 10L)),
        categories = listOf(Category("food", "خوراک", false)),
        transactions = listOf(
            Transaction(
                id = "t1", amountMinor = 250_000, currency = "IRT", type = TxType.EXPENSE, accountId = "cash",
                categoryId = "food", occurredAt = 1_700_000_000_000L, description = "نان و پنیر",
                merchant = null, notes = "یادداشت", createdAt = 1L, updatedAt = 2L, deletedAt = null,
            ),
        ),
        budgets = listOf(Budget("b1", "خوراک", 2_000_000, 20_000L, 20_030L, categoryId = "food")),
        groups = listOf(ExpenseGroup("g1", "سفر", 5L)),
        members = listOf(GroupMember("m1", "g1", "علی"), GroupMember("m2", "g1", "نازی")),
        expenses = listOf(SharedExpense("e1", "g1", "هتل", 1_001L, "m1", 6L, 6L)),
        shares = listOf(ExpenseShare("e1", "m1", 501L), ExpenseShare("e1", "m2", 500L)),
        settlements = listOf(Settlement("s1", "g1", "m2", "m1", 500L, 7L)),
    )

    private fun assertInvalid(snapshot: BackupSnapshot) {
        val bytes = BackupCodec.encode(snapshot, 0L).toByteArray()
        try {
            BackupCodec.decode(bytes)
            fail("expected INVALID_DATA")
        } catch (e: BackupException) {
            assertEquals(Code.INVALID_DATA, e.code)
        }
    }

    @Test
    fun roundTripKeepsEveryField() {
        val original = sample()
        val text = BackupCodec.encode(original, exportedAtMillis = 123L)
        assertEquals(original, BackupCodec.decode(text.toByteArray(Charsets.UTF_8)))
    }

    @Test
    fun rejectsNonJson() {
        expectCode(Code.NOT_JSON, "this is not json".toByteArray())
    }

    @Test
    fun rejectsForeignFormat() {
        expectCode(Code.WRONG_FORMAT, """{"format":"other","backupVersion":2}""".toByteArray())
    }

    @Test
    fun rejectsUnknownVersion() {
        expectCode(Code.UNSUPPORTED_VERSION, """{"format":"mr91-wealth-backup","backupVersion":99}""".toByteArray())
    }

    @Test
    fun rejectsOversizedFiles() {
        expectCode(Code.TOO_LARGE, ByteArray((BackupCodec.MAX_BYTES + 1).toInt()) { 32 })
    }

    @Test
    fun rejectsDanglingAccountReference() {
        assertInvalid(sample().copy(transactions = sample().transactions.map { it.copy(accountId = "ghost") }))
    }

    @Test
    fun rejectsSharesThatDoNotAddUp() {
        assertInvalid(sample().copy(shares = listOf(ExpenseShare("e1", "m1", 501L), ExpenseShare("e1", "m2", 499L))))
    }

    @Test
    fun rejectsAmountsOutsideRange() {
        assertInvalid(sample().copy(transactions = sample().transactions.map { it.copy(amountMinor = -1L) }))
    }

    @Test
    fun rejectsDuplicateIds() {
        val t = sample().transactions.first()
        assertInvalid(sample().copy(transactions = listOf(t, t)))
    }

    @Test
    fun rejectsSettlementBetweenStrangers() {
        assertInvalid(sample().copy(settlements = listOf(Settlement("s1", "g1", "m2", "outsider", 5L, 7L))))
    }

    private fun expectCode(code: Code, bytes: ByteArray) {
        try {
            BackupCodec.decode(bytes)
            fail("expected $code")
        } catch (e: BackupException) {
            assertEquals(code, e.code)
        }
    }
}
