package com.mr91.wealth.domain

import com.mr91.wealth.data.Account
import com.mr91.wealth.data.AccountType
import com.mr91.wealth.data.Budget
import com.mr91.wealth.data.Transaction
import com.mr91.wealth.data.TxType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class LedgerTest {

    private val day = LocalDate.of(2025, 3, 22).toEpochDay()

    private fun tx(
        id: String,
        type: TxType,
        amount: Long,
        account: String,
        category: String? = null,
        linked: String? = null,
        dayOffset: Long = 0,
        deleted: Boolean = false,
    ) = Transaction(
        id = id, amountMinor = amount, currency = "IRT", type = type, accountId = account,
        categoryId = category, occurredAt = JalaliCalendar.millisForDay(day + dayOffset, nowMillis = 0L),
        description = id, linkedAccountId = linked,
        deletedAt = if (deleted) 1L else null,
    )

    private val accounts = listOf(
        Account("a", "A", AccountType.BANK, openingMinor = 10_000),
        Account("b", "B", AccountType.BANK, openingMinor = 0),
    )

    @Test
    fun transferMovesMoneyWithoutBecomingIncomeOrExpense() {
        val totals = Ledger.totals(accounts, listOf(tx("x", TxType.TRANSFER, 2_500, "a", linked = "b")))
        assertEquals(10_000L, totals.balanceToman)
        assertEquals(0L, totals.incomeToman)
        assertEquals(0L, totals.expenseToman)
        assertEquals(7_500L, Ledger.balances(accounts, listOf(tx("x", TxType.TRANSFER, 2_500, "a", linked = "b")))["a"])
        assertEquals(2_500L, Ledger.balances(accounts, listOf(tx("x", TxType.TRANSFER, 2_500, "a", linked = "b")))["b"])
    }

    @Test
    fun incomeAndExpenseUpdateBalanceAndTotals() {
        val txs = listOf(
            tx("i", TxType.INCOME, 5_000, "a", category = "salary"),
            tx("e", TxType.EXPENSE, 1_200, "a", category = "food"),
        )
        val totals = Ledger.totals(accounts, txs)
        assertEquals(13_800L, totals.balanceToman)
        assertEquals(5_000L, totals.incomeToman)
        assertEquals(1_200L, totals.expenseToman)
        assertEquals(3_800L, totals.netToman)
    }

    @Test
    fun deletedTransactionsAreExcludedWhenCallerFiltersThem() {
        val active = listOf(tx("e", TxType.EXPENSE, 1_200, "a", category = "food"))
        val withTrash = active + tx("gone", TxType.EXPENSE, 9_000, "a", category = "food", deleted = true)
        assertEquals(
            Ledger.totals(accounts, active).balanceToman,
            Ledger.totals(accounts, withTrash.filter { it.deletedAt == null }).balanceToman,
        )
    }

    @Test
    fun rangeFiltersIncomeAndExpenseByDay() {
        val txs = listOf(
            tx("old", TxType.EXPENSE, 700, "a", category = "food", dayOffset = -40),
            tx("now", TxType.EXPENSE, 300, "a", category = "food"),
        )
        val month = Periods.monthRange(day)
        assertEquals(300L, Ledger.totals(accounts, txs, month).expenseToman)
    }

    @Test
    fun equalSplitReconcilesRemainderExactly() {
        assertEquals(listOf(334L, 333L, 333L), Ledger.splitEqual(1_000, 3))
        assertEquals(listOf(0L, 0L), Ledger.splitEqual(0, 2))
        val parts = Ledger.splitEqual(999_999_999_999L, 7)
        assertEquals(999_999_999_999L, parts.sum())
        assertTrue(parts.max() - parts.min() <= 1)
    }

    @Test
    fun budgetThresholdsAndStates() {
        assertEquals(BudgetState.ON_TRACK, Ledger.progress(1_000, 500).state)
        assertEquals(BudgetState.WARNING, Ledger.progress(1_000, 800).state)
        assertEquals(BudgetState.REACHED, Ledger.progress(1_000, 1_000).state)
        assertEquals(BudgetState.OVERSPENT, Ledger.progress(1_000, 1_001).state)
        assertEquals(1_000, Ledger.progress(1_000, 1_000_000).percent)
    }

    @Test
    fun budgetSpendingFollowsCategoryAndPeriod() {
        val month = Periods.monthRange(day)
        val budget = Budget("b1", "خوراک", 1_000, month.startDay, month.endDay, categoryId = "food")
        val txs = listOf(
            tx("f1", TxType.EXPENSE, 300, "a", category = "food"),
            tx("f2", TxType.EXPENSE, 200, "a", category = "food"),
            tx("other", TxType.EXPENSE, 900, "a", category = "shopping"),
            tx("inc", TxType.INCOME, 5_000, "a", category = "salary"),
            tx("old", TxType.EXPENSE, 400, "a", category = "food", dayOffset = -60),
        )
        assertEquals(500L, Ledger.spentFor(budget, txs))
        assertEquals(500L, Ledger.spentFor(budget, txs.filter { it.id != "other" }))
        val allExpenses = budget.copy(categoryId = null)
        assertEquals(1_400L, Ledger.spentFor(allExpenses, txs))
    }

    @Test
    fun netBalancesAndSettlementPlanClearEveryone() {
        // A paid 900 for A, B, C. B paid 100 for B and C.
        val expenses = listOf(
            ExpenseFact("e1", payerId = "a", amountToman = 900),
            ExpenseFact("e2", payerId = "b", amountToman = 100),
        )
        val shares = listOf(
            ShareFact("e1", "a", 300), ShareFact("e1", "b", 300), ShareFact("e1", "c", 300),
            ShareFact("e2", "b", 50), ShareFact("e2", "c", 50),
        )
        val net = Ledger.netBalances(listOf("a", "b", "c"), expenses, shares, emptyList())
        assertEquals(mapOf("a" to 600L, "b" to -250L, "c" to -350L), net)
        assertEquals(0L, net.values.sum())

        val plan = Ledger.settlementPlan(net)
        assertEquals(listOf(Transfer("c", "a", 350), Transfer("b", "a", 250)), plan)
    }

    @Test
    fun partialSettlementReducesRemainingPlan() {
        val net = Ledger.netBalances(
            listOf("a", "b", "c"),
            listOf(ExpenseFact("e1", "a", 900), ExpenseFact("e2", "b", 100)),
            listOf(
                ShareFact("e1", "a", 300), ShareFact("e1", "b", 300), ShareFact("e1", "c", 300),
                ShareFact("e2", "b", 50), ShareFact("e2", "c", 50),
            ),
            listOf(SettlementFact("c", "a", 350)),
        )
        assertEquals(listOf(Transfer("b", "a", 250)), Ledger.settlementPlan(net))
    }

    @Test
    fun fullySettledGroupHasNoPlan() {
        val net = mapOf("a" to 0L, "b" to 0L)
        assertTrue(Ledger.settlementPlan(net).isEmpty())
    }

    @Test
    fun expenseByCategoryIsSortedAndIgnoresIncome() {
        val txs = listOf(
            tx("a", TxType.EXPENSE, 100, "a", category = "food"),
            tx("b", TxType.EXPENSE, 700, "a", category = "shopping"),
            tx("c", TxType.EXPENSE, 250, "a", category = "food"),
            tx("d", TxType.INCOME, 9_999, "a", category = "salary"),
        )
        assertEquals(listOf("shopping" to 700L, "food" to 350L), Ledger.expenseByCategory(txs, null))
    }
}
