package com.mr91.wealth.domain

import com.mr91.wealth.domain.Money.AmountProblem
import com.mr91.wealth.domain.Money.Parsed
import org.junit.Assert.assertEquals
import org.junit.Test

class MoneyTest {

    @Test
    fun parsesPlainSeparatedAndPersianDigitAmounts() {
        assertEquals(Parsed.Ok(1_200_000L), Money.parse("1200000"))
        assertEquals(Parsed.Ok(1_200_000L), Money.parse("1,200,000"))
        assertEquals(Parsed.Ok(1_200_000L), Money.parse("۱٬۲۰۰٬۰۰۰"))
        assertEquals(Parsed.Ok(123L), Money.parse("١٢٣"))
        assertEquals(Parsed.Ok(45L), Money.parse("  ۴۵  "))
    }

    @Test
    fun rejectsEmptyZeroNegativeDecimalAndGarbage() {
        assertEquals(Parsed.Invalid(AmountProblem.EMPTY), Money.parse(""))
        assertEquals(Parsed.Invalid(AmountProblem.EMPTY), Money.parse("   "))
        assertEquals(Parsed.Invalid(AmountProblem.ZERO), Money.parse("0"))
        assertEquals(Parsed.Invalid(AmountProblem.ZERO), Money.parse("000"))
        assertEquals(Parsed.Invalid(AmountProblem.NEGATIVE), Money.parse("-5"))
        assertEquals(Parsed.Invalid(AmountProblem.DECIMAL_NOT_ALLOWED), Money.parse("12.5"))
        assertEquals(Parsed.Invalid(AmountProblem.NOT_NUMERIC), Money.parse("12a"))
        assertEquals(Parsed.Invalid(AmountProblem.NOT_NUMERIC), Money.parse("-"))
    }

    @Test
    fun rejectsHugeAmountsWithoutOverflow() {
        assertEquals(Parsed.Invalid(AmountProblem.TOO_LARGE), Money.parse("9999999999999999"))
        assertEquals(Parsed.Invalid(AmountProblem.TOO_LARGE), Money.parse("1000000000000001"))
        assertEquals(Parsed.Invalid(AmountProblem.TOO_LARGE), Money.parse("99999999999999999999999"))
        assertEquals(Parsed.Ok(Money.MAX_TOMAN), Money.parse("1000000000000000"))
    }

    @Test
    fun allowsNegativeOnlyWhenRequested() {
        assertEquals(Parsed.Ok(-5L), Money.parse("-5", allowNegative = true))
        assertEquals(Parsed.Ok(0L), Money.parse("0", allowZero = true))
    }

    @Test
    fun formatsWithGroupingAndUnit() {
        assertEquals("1,234,567 تومان", Money.format(1_234_567L, persianDigits = false))
        assertEquals("۱,۲۳۴,۵۶۷ تومان", Money.format(1_234_567L, persianDigits = true))
        assertEquals("-۱,۵۰۰ تومان", Money.format(-1_500L, persianDigits = true))
        assertEquals("0 تومان", Money.format(0L, persianDigits = false))
    }

    @Test
    fun compactUsesPersianUnits() {
        assertEquals("1.2 میلیون تومان", Money.compact(1_250_000L, persianDigits = false))
        assertEquals("3 میلیارد تومان", Money.compact(3_000_000_000L, persianDigits = false))
        assertEquals("999 تومان", Money.compact(999L, persianDigits = false))
        assertEquals("-۲ هزار تومان", Money.compact(-2_000L, persianDigits = true))
        assertEquals("۱٫۲ میلیون تومان", Money.compact(1_250_000L, persianDigits = true))
    }
}
