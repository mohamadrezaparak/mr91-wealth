package com.mr91.wealth.domain

import com.mr91.wealth.data.Transaction
import com.mr91.wealth.data.TxType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CsvExportTest {

    @Test
    fun escapesQuotesAndNeutralisesFormulas() {
        assertEquals("\"a\"\"b\"", CsvExport.escape("a\"b"))
        assertEquals("\"'=SUM(A1)\"", CsvExport.escape("=SUM(A1)"))
        assertEquals("\"'-1+1\"", CsvExport.escape("-1+1"))
    }

    @Test
    fun encodesBomHeaderAndRows() {
        val tx = Transaction(
            id = "1", amountMinor = 2_500, currency = "IRT", type = TxType.EXPENSE, accountId = "cash",
            categoryId = "food", occurredAt = 1_700_000_000_000L, description = "نان", createdAt = 0L, updatedAt = 0L,
        )
        val text = CsvExport.encode(listOf(tx), { "نقد" }, { "خوراک" })
        assertTrue(text.startsWith(CsvExport.BOM))
        assertTrue(text.contains("\"2500\""))
        assertTrue(text.contains("\"نقد\""))
        assertTrue(text.contains("\"خوراک\""))
    }
}
