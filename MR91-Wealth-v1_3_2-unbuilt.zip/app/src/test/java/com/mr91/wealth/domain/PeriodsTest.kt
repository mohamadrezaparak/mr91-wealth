package com.mr91.wealth.domain

import com.mr91.wealth.domain.Period
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate

class PeriodsTest {

    private val saturday = LocalDate.of(2025, 3, 22).toEpochDay() // 1404/01/02
    private val friday = LocalDate.of(2025, 3, 28).toEpochDay()

    @Test
    fun weekStartsOnSaturday() {
        assertEquals(saturday, Periods.range(Period.WEEK, saturday)!!.startDay)
        assertEquals(saturday, Periods.range(Period.WEEK, friday)!!.startDay)
    }

    @Test
    fun monthStartsOnFirstJalaliDay() {
        val range = Periods.range(Period.MONTH, saturday)!!
        assertEquals(LocalDate.of(2025, 3, 21).toEpochDay(), range.startDay)
        assertEquals(saturday, range.endDay)
    }

    @Test
    fun monthRangeCoversWholeMonth() {
        val range = Periods.monthRange(saturday)
        assertEquals(LocalDate.of(2025, 3, 21).toEpochDay(), range.startDay)
        assertEquals(LocalDate.of(2025, 4, 20).toEpochDay(), range.endDay) // Farvardin has 31 days
    }

    @Test
    fun allPeriodHasNoFilter() {
        assertNull(Periods.range(Period.ALL, saturday))
    }

    @Test
    fun lastMonthsAreContiguous() {
        val months = Periods.lastMonths(saturday, 6)
        assertEquals(6, months.size)
        for (i in 1 until months.size) {
            assertEquals(months[i - 1].endDay + 1, months[i].startDay)
        }
        assertEquals(Periods.monthRange(saturday), months.last())
    }

    @Test
    fun previousPeriodsAreComparable() {
        val lastMonth = Periods.previous(Period.MONTH, saturday)!!
        assertEquals(LocalDate.of(2025, 2, 19).toEpochDay(), lastMonth.startDay) // 1403/12/01, leap year
        assertEquals(LocalDate.of(2025, 3, 20).toEpochDay(), lastMonth.endDay)   // 1403/12/30
        assertEquals(saturday - 1, Periods.previous(Period.WEEK, saturday)!!.endDay)
        assertEquals(saturday - 1, Periods.previous(Period.TODAY, saturday)!!.startDay)
        assertNull(Periods.previous(Period.ALL, saturday))
    }
}
