package com.mr91.wealth.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mr91.wealth.data.Account
import com.mr91.wealth.data.Category
import com.mr91.wealth.data.Transaction
import com.mr91.wealth.data.TxType
import com.mr91.wealth.domain.JalaliCalendar
import com.mr91.wealth.domain.Money
import com.mr91.wealth.ui.theme.LocalMR91Colors

/** Whether numbers are shown with Persian digits. Provided once at the root from settings. */
val LocalPersianDigits = compositionLocalOf { true }

/** Space the scrolling content must leave at the bottom for the floating navigation bar. */
val LocalBottomReserve = compositionLocalOf { 150.dp }

val CategoryPalette: List<Color> = listOf(
    Color(0xFF3FE0C5), Color(0xFF5AA9FF), Color(0xFFFFC145), Color(0xFFFF6F9C),
    Color(0xFF9B8CFF), Color(0xFF7BD389), Color(0xFFFF9A6B), Color(0xFF8FA8C0),
)

fun colorAt(index: Int): Color = CategoryPalette[index % CategoryPalette.size]

@Composable
fun money(toman: Long): String = Money.format(toman, LocalPersianDigits.current)

@Composable
fun numText(value: Long): String {
    val text = value.toString()
    return if (LocalPersianDigits.current) Money.toPersianDigits(text) else text
}

fun typeLabel(type: TxType): String = when (type.canonical()) {
    TxType.INCOME -> "درآمد"
    TxType.TRANSFER -> "انتقال"
    else -> "هزینه"
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (trailing != null) trailing()
    }
}

@Composable
fun OfflineBadge() {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).background(LocalMR91Colors.current.income, CircleShape))
            Spacer(Modifier.width(6.dp))
            Text("آفلاین", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
        }
    }
}

/** Card with a soft border and a spring press effect when it is clickable. */
@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val source = remember { MutableInteractionSource() }
    val shape = MaterialTheme.shapes.medium
    val color = MaterialTheme.colorScheme.surfaceContainer
    val border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
    val full = modifier.fillMaxWidth().pressScale(source)
    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = full,
            interactionSource = source,
            shape = shape,
            color = color,
            border = border,
        ) {
            Column(Modifier.padding(18.dp), content = content)
        }
    } else {
        Surface(modifier = full, shape = shape, color = color, border = border) {
            Column(Modifier.padding(18.dp), content = content)
        }
    }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier.padding(top = 6.dp),
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
fun Avatar(name: String, color: Color, size: Dp = 40.dp) {
    Box(
        Modifier.size(size).background(color.copy(alpha = 0.22f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            name.trim().firstOrNull()?.toString() ?: "?",
            color = color,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium,
        )
    }
}

/** Gently floating icon with a caption. Used wherever a list is empty, so no screen looks broken. */
@Composable
fun EmptyState(icon: ImageVector, text: String, modifier: Modifier = Modifier) {
    val reduce = rememberReduceMotion()
    val transition = rememberInfiniteTransition(label = "empty")
    val lift by transition.animateFloat(
        initialValue = 0f,
        targetValue = -8f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "lift",
    )
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .size(88.dp)
                .graphicsLayer { translationY = if (reduce) 0f else lift * density }
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        }
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

/** Single-choice chips in a horizontally scrolling row. Safe inside vertical scroll containers. */
@Composable
fun <T> ChoiceRow(options: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) },
            )
        }
    }
}

/** One transaction line. Income is green, expense red, transfer neutral. */
@Composable
fun TxRow(t: Transaction, accountName: String, categoryName: String?, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val colors = LocalMR91Colors.current
    val kind = t.type.canonical()
    val amountColor = when (kind) {
        TxType.INCOME -> colors.income
        TxType.TRANSFER -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> colors.expense
    }
    val sign = when (kind) {
        TxType.INCOME -> "+"
        TxType.TRANSFER -> ""
        else -> "−"
    }
    val day = JalaliCalendar.format(JalaliCalendar.epochDayOf(t.occurredAt), LocalPersianDigits.current)
    val iconColor = if (categoryName == null) MaterialTheme.colorScheme.primary else colorAt(categoryName.hashCode().let { if (it < 0) -it else it })
    AppCard(modifier = modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(iconColor.copy(alpha = 0.18f), CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(12.dp).background(iconColor, CircleShape))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(t.description.ifBlank { categoryName ?: typeLabel(t.type) }, fontWeight = FontWeight.Medium)
                val details = listOfNotNull(day, accountName, categoryName).joinToString(" · ")
                Text(details, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(sign + money(t.amountMinor), color = amountColor, fontWeight = FontWeight.SemiBold)
        }
    }
}

data class MonthPoint(val label: String, val income: Long, val expense: Long)

/** Income and expense bars for several months. The bars grow in on first show. */
@Composable
fun MonthlyBars(points: List<MonthPoint>, modifier: Modifier = Modifier) {
    val colors = LocalMR91Colors.current
    val reduce = rememberReduceMotion()
    val grow = remember { Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(points) {
        if (!reduce) {
            grow.snapTo(0f)
            grow.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        }
    }
    val max = points.maxOfOrNull { maxOf(it.income, it.expense) }?.takeIf { it > 0 } ?: 1L
    Column(modifier) {
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val slot = size.width / points.size.coerceAtLeast(1)
            val barWidth = slot * 0.26f
            points.forEachIndexed { i, p ->
                val x = i * slot + slot * 0.17f
                val incomeH = size.height * (p.income.toFloat() / max) * grow.value
                val expenseH = size.height * (p.expense.toFloat() / max) * grow.value
                if (incomeH > 0f) {
                    drawRoundRect(colors.income, Offset(x, size.height - incomeH), Size(barWidth, incomeH), CornerRadius(barWidth / 2f))
                }
                if (expenseH > 0f) {
                    drawRoundRect(colors.expense, Offset(x + barWidth + 5f, size.height - expenseH), Size(barWidth, expenseH), CornerRadius(barWidth / 2f))
                }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            points.forEach { p ->
                Text(p.label, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

/** Donut chart with a sweep-in animation. [center] is drawn over the hole. */
@Composable
fun DonutChart(slices: List<Pair<Color, Long>>, modifier: Modifier = Modifier, center: @Composable () -> Unit) {
    val reduce = rememberReduceMotion()
    val sweep = remember { Animatable(if (reduce) 1f else 0f) }
    val total = slices.sumOf { it.second }.coerceAtLeast(1L)
    LaunchedEffect(slices) {
        if (!reduce) {
            sweep.snapTo(0f)
            sweep.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
        }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 22.dp.toPx(), cap = StrokeCap.Round)
            val diameter = size.minDimension - stroke.width
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            var start = -90f
            slices.forEach { (color, value) ->
                val arc = 360f * (value.toFloat() / total) * sweep.value
                if (arc > 0.5f) {
                    drawArc(
                        color = color,
                        startAngle = start + 1.5f,
                        sweepAngle = (arc - 3f).coerceAtLeast(0.5f),
                        useCenter = false,
                        topLeft = topLeft,
                        size = Size(diameter, diameter),
                        style = stroke,
                    )
                }
                start += arc
            }
        }
        center()
    }
}

/** Circular progress for savings goals. */
@Composable
fun ProgressRing(fraction: Float, color: Color, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val reduce = rememberReduceMotion()
    val animated by animateFloatAsState(
        targetValue = fraction.coerceIn(0f, 1f),
        animationSpec = if (reduce) snap() else tween(900, easing = FastOutSlowInEasing),
        label = "ring",
    )
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            val diameter = size.minDimension - stroke.width
            val topLeft = Offset((size.width - diameter) / 2f, (size.height - diameter) / 2f)
            drawArc(track, -90f, 360f, false, topLeft, Size(diameter, diameter), style = stroke)
            drawArc(color, -90f, 360f * animated, false, topLeft, Size(diameter, diameter), style = stroke)
        }
        content()
    }
}

fun List<Account>.nameOf(id: String): String = firstOrNull { it.id == id }?.name ?: "—"

fun List<Category>.nameOfOrNull(id: String?): String? = firstOrNull { it.id == id }?.name
