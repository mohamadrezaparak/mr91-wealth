package com.mr91.wealth.ui.theme

import android.os.Build
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

enum class Accent(val label: String, val color: Color) {
    BRAND("آبی MR91", BrandCyan),
    TEAL("فیروزه‌ای", Color(0xFF3FE0C5)),
    NEON_BLUE("آبی نئونی", Color(0xFF5AA9FF)),
    INDIGO("نیلی", Color(0xFF9B8CFF)),
    AMBER("کهربایی", Color(0xFFFFC145)),
    ROSE("گلی", Color(0xFFFF6F9C)),
}

/** Semantic colors that are not part of Material's scheme. */
data class MR91Colors(
    val income: Color,
    val expense: Color,
    val warning: Color,
    val glassTint: Color,
)

private val DarkExtras = MR91Colors(
    income = Color(0xFF7BE0A0), expense = Color(0xFFFF8A80), warning = Color(0xFFFFC145), glassTint = Color(0x221B2F4A),
)
private val LightExtras = MR91Colors(
    income = Color(0xFF1B8A5A), expense = Color(0xFFB3261E), warning = Color(0xFFB7791F), glassTint = Color(0x33FFFFFF),
)

val LocalMR91Colors = staticCompositionLocalOf { DarkExtras }

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

private fun darkScheme(accent: Color) = darkColorScheme(
    primary = accent,
    onPrimary = Color(0xFF031016),
    primaryContainer = if (accent == BrandCyan) BrandNavy else lerp(accent, Color.Black, 0.62f),
    onPrimaryContainer = if (accent == BrandCyan) Color(0xFFCFF4FF) else lerp(accent, Color.White, 0.78f),
    secondary = Color(0xFF8DB8FF),
    onSecondary = Color(0xFF061226),
    secondaryContainer = Color(0xFF1C2E52),
    onSecondaryContainer = Color(0xFFDCE8FF),
    tertiary = Color(0xFFFFC145),
    onTertiary = Color(0xFF2B1D00),
    background = Color(0xFF020D24),
    onBackground = Color(0xFFEAF6F5),
    surface = Color(0xFF0B1628),
    onSurface = Color(0xFFEAF6F5),
    surfaceVariant = Color(0xFF15243B),
    onSurfaceVariant = Color(0xFFA7BAC4),
    surfaceContainerLowest = Color(0xFF040913),
    surfaceContainerLow = Color(0xFF0D1A2D),
    surfaceContainer = Color(0xFF112037),
    surfaceContainerHigh = Color(0xFF172944),
    surfaceContainerHighest = Color(0xFF1D3350),
    outline = Color(0xFF3B5268),
    outlineVariant = Color(0xFF223547),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF3C0A08),
    errorContainer = Color(0xFF5A1A16),
    onErrorContainer = Color(0xFFFFDAD6),
)

private fun lightScheme(accent: Color) = lightColorScheme(
    primary = if (accent == BrandCyan) BrandNavy else lerp(accent, Color.Black, 0.35f),
    onPrimary = Color.White,
    primaryContainer = lerp(accent, Color.White, 0.72f),
    onPrimaryContainer = lerp(accent, Color.Black, 0.7f),
    secondary = Color(0xFF2F5BB7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDE8FF),
    onSecondaryContainer = Color(0xFF0E2A5C),
    tertiary = Color(0xFFB7791F),
    onTertiary = Color.White,
    background = Color(0xFFF3F8FA),
    onBackground = Color(0xFF0B1F2A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0B1F2A),
    surfaceVariant = Color(0xFFE2EEF2),
    onSurfaceVariant = Color(0xFF3D5560),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF7FBFC),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEEF5F7),
    surfaceContainerHighest = Color(0xFFE6EFF2),
    outline = Color(0xFF7D929B),
    outlineVariant = Color(0xFFD3E0E5),
    error = Color(0xFFB3261E),
    onError = Color.White,
    errorContainer = Color(0xFFF9DEDC),
    onErrorContainer = Color(0xFF410E0B),
)

@Composable
fun MR91Theme(darkTheme: Boolean, accent: Accent, dynamicColor: Boolean, content: @Composable () -> Unit) {
    val context = LocalContext.current
    val scheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        darkTheme -> darkScheme(accent.color)
        else -> lightScheme(accent.color)
    }
    CompositionLocalProvider(LocalMR91Colors provides if (darkTheme) DarkExtras else LightExtras) {
        MaterialTheme(colorScheme = scheme, shapes = AppShapes, content = content)
    }
}
