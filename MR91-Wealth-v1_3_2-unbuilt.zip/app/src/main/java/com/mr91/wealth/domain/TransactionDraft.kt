package com.mr91.wealth.domain

import com.mr91.wealth.data.TxType

/** What the editor sends to the ViewModel. Amounts are already parsed to whole toman. */
data class TransactionDraft(
    val id: String,
    val type: TxType,
    val amountToman: Long,
    val accountId: String,
    val toAccountId: String?,
    val categoryId: String?,
    val occurredAt: Long,
    val description: String,
)
