package com.mr91.wealth.ui

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mr91.wealth.data.*
import com.mr91.wealth.domain.*
import com.mr91.wealth.ui.theme.Accent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.UUID
import kotlin.math.abs

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class Settings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val persianDigits: Boolean = true,
    val accent: Accent = Accent.BRAND,
    val dynamicColor: Boolean = false,
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("mr91_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun update(settings: Settings) {
        prefs.edit()
            .putString(KEY_THEME, settings.theme.name)
            .putBoolean(KEY_DIGITS, settings.persianDigits)
            .putString(KEY_ACCENT, settings.accent.name)
            .putBoolean(KEY_DYNAMIC, settings.dynamicColor)
            .apply()
        _state.value = settings
    }

    private fun read(): Settings = Settings(
        theme = enumOr(KEY_THEME, ThemeMode.SYSTEM),
        persianDigits = prefs.getBoolean(KEY_DIGITS, true),
        accent = enumOr(KEY_ACCENT, Accent.BRAND),
        dynamicColor = prefs.getBoolean(KEY_DYNAMIC, false),
    )

    private inline fun <reified E : Enum<E>> enumOr(key: String, default: E): E =
        runCatching { enumValueOf<E>(prefs.getString(key, null) ?: "") }.getOrDefault(default)

    private companion object {
        const val KEY_THEME = "theme"
        const val KEY_DIGITS = "persian_digits"
        const val KEY_ACCENT = "accent"
        const val KEY_DYNAMIC = "dynamic_color"
    }
}

sealed interface SaveResult {
    data object Saved : SaveResult
    data object PossibleDuplicate : SaveResult
    data class Invalid(val message: String) : SaveResult
}

data class UiMessage(val text: String, val actionLabel: String? = null, val onAction: (() -> Unit)? = null)

class AppViewModel(
    private val repo: WealthRepository,
    private val settingsStore: SettingsStore,
) : ViewModel() {

    private fun <T> Flow<T>.hold(initial: T): StateFlow<T> =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val accounts = repo.accounts.hold(emptyList<Account>())
    val categories = repo.categories.hold(emptyList<Category>())
    val transactions = repo.transactions.hold(emptyList<Transaction>())
    val budgets = repo.budgets.hold(emptyList<Budget>())
    val groups = repo.groups.hold(emptyList<ExpenseGroup>())
    val members = repo.members.hold(emptyList<GroupMember>())
    val expenses = repo.expenses.hold(emptyList<SharedExpense>())
    val shares = repo.shares.hold(emptyList<ExpenseShare>())
    val settlements = repo.settlements.hold(emptyList<Settlement>())

    val settings: StateFlow<Settings> = settingsStore.state
    val period = MutableStateFlow(Period.MONTH)
    val pendingRestore = MutableStateFlow<BackupSnapshot?>(null)

    private val _messages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8)
    val messages: SharedFlow<UiMessage> = _messages.asSharedFlow()

    init {
        viewModelScope.launch { repo.seedIfEmpty() }
    }

    private fun say(text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
        _messages.tryEmit(UiMessage(text, actionLabel, onAction))
    }

    private fun launchSafe(errorText: String, block: suspend () -> Unit) = viewModelScope.launch {
        try {
            block()
        } catch (e: IllegalArgumentException) {
            say(errorText)
        }
    }

    fun updateSettings(settings: Settings) = settingsStore.update(settings)

    // ---- Transactions -------------------------------------------------------------------------

    fun saveTransaction(draft: TransactionDraft, confirmSimilar: Boolean, onResult: (SaveResult) -> Unit) {
        viewModelScope.launch {
            val problem = validate(draft)
            if (problem != null) {
                onResult(SaveResult.Invalid(problem))
                return@launch
            }
            val now = System.currentTimeMillis()
            val existing = transactions.value.firstOrNull { it.id == draft.id }
            val similar = transactions.value.any { t ->
                t.id != draft.id && t.type == draft.type && t.accountId == draft.accountId &&
                    t.amountMinor == draft.amountToman && t.description == draft.description &&
                    abs(t.occurredAt - draft.occurredAt) <= DUPLICATE_WINDOW_MS
            }
            if (similar && !confirmSimilar) {
                onResult(SaveResult.PossibleDuplicate)
                return@launch
            }
            repo.saveTransaction(
                Transaction(
                    id = draft.id,
                    amountMinor = draft.amountToman,
                    currency = Money.CURRENCY_CODE,
                    type = draft.type,
                    accountId = draft.accountId,
                    categoryId = draft.categoryId,
                    occurredAt = draft.occurredAt,
                    description = draft.description,
                    linkedAccountId = draft.toAccountId,
                    createdAt = existing?.createdAt ?: now,
                    updatedAt = now,
                    deletedAt = null,
                )
            )
            onResult(SaveResult.Saved)
        }
    }

    private fun validate(d: TransactionDraft): String? {
        val accountIds = accounts.value.map { it.id }.toSet()
        return when {
            d.amountToman !in 1..Money.MAX_TOMAN -> "مبلغ باید بین ۱ و ${Money.format(Money.MAX_TOMAN, true)} باشد"
            d.accountId !in accountIds -> "حساب انتخاب‌شده معتبر نیست"
            d.type == TxType.TRANSFER && (d.toAccountId == null || d.toAccountId == d.accountId || d.toAccountId !in accountIds) ->
                "حساب مقصد باید معتبر و متفاوت باشد"
            d.type != TxType.TRANSFER && d.categoryId == null -> "دسته‌بندی را انتخاب کنید"
            d.type != TxType.TRANSFER && categories.value.none { it.id == d.categoryId } -> "دسته‌بندی معتبر نیست"
            d.description.length > 200 -> "شرح نباید بیش از ۲۰۰ نویسه باشد"
            JalaliCalendar.epochDayOf(d.occurredAt) > JalaliCalendar.todayEpochDay() -> "تاریخ در آینده است"
            else -> null
        }
    }

    /** Soft delete with an undo action in the snackbar. */
    fun deleteTransaction(id: String) = viewModelScope.launch {
        repo.softDeleteTransaction(id, System.currentTimeMillis())
        say("تراکنش به سطل زباله رفت", "برگردان") {
            viewModelScope.launch { repo.restoreTransaction(id, System.currentTimeMillis()) }
        }
    }

    // ---- Accounts and savings goals -----------------------------------------------------------

    fun saveAccount(
        existing: Account?,
        name: String,
        type: AccountType,
        openingToman: Long,
        targetToman: Long?,
        colorArgb: Long?,
    ) = launchSafe("حساب ذخیره نشد") {
        val clean = name.trim()
        require(clean.isNotEmpty() && clean.length <= 60)
        require(openingToman in -Money.MAX_TOMAN..Money.MAX_TOMAN)
        require(targetToman == null || targetToman in 1..Money.MAX_TOMAN)
        require(existing != null || accounts.value.size < MAX_ACCOUNTS)
        repo.saveAccount(
            Account(
                id = existing?.id ?: UUID.randomUUID().toString(),
                name = clean,
                type = type,
                currency = Money.CURRENCY_CODE,
                openingMinor = openingToman,
                archived = false,
                createdAt = existing?.createdAt ?: System.currentTimeMillis(),
                targetMinor = targetToman,
                colorArgb = colorArgb,
            )
        )
    }

    /** Archiving hides the account and removes it from the total. Undo brings it back. */
    fun archiveAccount(account: Account) = viewModelScope.launch {
        repo.saveAccount(account.copy(archived = true))
        say("حساب بایگانی شد", "برگردان") {
            viewModelScope.launch { repo.saveAccount(account.copy(archived = false)) }
        }
    }

    // ---- Budgets ------------------------------------------------------------------------------

    fun saveBudget(categoryId: String?, limitToman: Long) = launchSafe("بودجه ذخیره نشد") {
        require(limitToman in 1..Money.MAX_TOMAN)
        val today = JalaliCalendar.todayEpochDay()
        val month = Periods.monthRange(today)
        if (budgets.value.any { it.categoryId == categoryId && it.startEpochDay == month.startDay }) {
            say("برای این دسته در این ماه بودجه وجود دارد")
            return@launchSafe
        }
        val categoryName = categories.value.firstOrNull { it.id == categoryId }?.name ?: "کل هزینه‌ها"
        val monthName = JalaliCalendar.monthName(JalaliCalendar.fromEpochDay(today).month)
        repo.upsertBudget(
            Budget(
                id = UUID.randomUUID().toString(),
                name = "$categoryName $monthName",
                amountMinor = limitToman,
                startEpochDay = month.startDay,
                endEpochDay = month.endDay,
                categoryId = categoryId,
            )
        )
    }

    fun deleteBudget(id: String) = viewModelScope.launch { repo.deleteBudget(id) }

    // ---- Groups -------------------------------------------------------------------------------

    fun createGroup(name: String) = launchSafe("گروه ساخته نشد") {
        val clean = name.trim()
        require(clean.isNotEmpty() && clean.length <= 80)
        repo.createGroup(ExpenseGroup(UUID.randomUUID().toString(), clean, System.currentTimeMillis()))
    }

    fun addMember(groupId: String, name: String) = launchSafe("عضو اضافه نشد") {
        val clean = name.trim()
        require(clean.isNotEmpty() && clean.length <= 60)
        require(members.value.count { it.groupId == groupId } < 50)
        repo.addMember(GroupMember(UUID.randomUUID().toString(), groupId, clean))
    }

    /** Splits [amountToman] equally between [participantIds] in the given order. Shares always add up exactly. */
    fun addSharedExpense(
        groupId: String,
        title: String,
        amountToman: Long,
        payerId: String,
        participantIds: List<String>,
    ) = launchSafe("هزینه گروهی ثبت نشد") {
        val groupMembers = members.value.filter { it.groupId == groupId }.map { it.id }.toSet()
        require(amountToman in 1..Money.MAX_TOMAN)
        require(participantIds.isNotEmpty() && participantIds.all { it in groupMembers })
        require(payerId in groupMembers)
        require(title.isNotBlank() && title.length <= 120)
        val id = UUID.randomUUID().toString()
        val parts = Ledger.splitEqual(amountToman, participantIds.size)
        val now = System.currentTimeMillis()
        repo.addSharedExpense(
            SharedExpense(id, groupId, title.trim(), amountToman, payerId, now, now),
            participantIds.mapIndexed { i, memberId -> ExpenseShare(id, memberId, parts[i]) },
        )
    }

    fun deleteSharedExpense(id: String) = viewModelScope.launch {
        repo.softDeleteSharedExpense(id, System.currentTimeMillis())
        say("هزینه حذف شد", "برگردان") {
            viewModelScope.launch { repo.restoreSharedExpense(id) }
        }
    }

    fun recordSettlement(groupId: String, fromId: String, toId: String, amountToman: Long) =
        launchSafe("پرداخت ثبت نشد") {
            require(amountToman in 1..Money.MAX_TOMAN)
            require(fromId != toId)
            repo.addSettlement(
                Settlement(UUID.randomUUID().toString(), groupId, fromId, toId, amountToman, System.currentTimeMillis())
            )
            say("پرداخت ثبت شد")
        }

    fun deleteGroup(groupId: String) = viewModelScope.launch { repo.deleteGroup(groupId) }

    // ---- Export and backup --------------------------------------------------------------------

    fun exportJson(resolver: ContentResolver, uri: Uri) = viewModelScope.launch {
        val result = runCatching {
            val text = BackupCodec.encode(repo.snapshot(), System.currentTimeMillis())
            writeText(resolver, uri, text)
        }
        say(if (result.isSuccess) "پشتیبان ذخیره شد" else "ذخیره پشتیبان انجام نشد")
    }

    /** Uses the full snapshot so archived accounts keep their names and deleted rows are skipped. */
    fun exportCsv(resolver: ContentResolver, uri: Uri) = viewModelScope.launch {
        val result = runCatching {
            val snap = repo.snapshot()
            val names = snap.accounts.associate { it.id to it.name }
            val cats = snap.categories.associate { it.id to it.name }
            val active = snap.transactions.filter { it.deletedAt == null }
            writeText(resolver, uri, CsvExport.encode(active, { names[it] ?: "—" }, { cats[it] ?: "" }))
        }
        say(if (result.isSuccess) "فایل CSV ساخته شد" else "ساخت فایل انجام نشد")
    }

    private suspend fun writeText(resolver: ContentResolver, uri: Uri, text: String) = withContext(Dispatchers.IO) {
        val out = resolver.openOutputStream(uri) ?: error("cannot open output")
        out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
    }

    /** Reads and validates the file. Nothing in the database changes until [confirmRestore]. */
    fun prepareRestore(resolver: ContentResolver, uri: Uri) = viewModelScope.launch {
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val input = resolver.openInputStream(uri) ?: error("cannot open input")
                val bytes = input.use { readCapped(it, BackupCodec.MAX_BYTES) }
                BackupCodec.decode(bytes)
            }
        }
        result.onSuccess { pendingRestore.value = it }
            .onFailure { say(restoreErrorText(it)) }
    }

    fun confirmRestore() {
        val snapshot = pendingRestore.value ?: return
        pendingRestore.value = null
        viewModelScope.launch {
            runCatching { repo.restore(snapshot) }
                .onSuccess { say("داده‌ها بازیابی شد") }
                .onFailure { say("بازیابی انجام نشد؛ داده‌های قبلی دست‌نخورده ماندند") }
        }
    }

    fun cancelRestore() {
        pendingRestore.value = null
    }

    private fun readCapped(input: InputStream, max: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0L
        while (true) {
            val n = input.read(buffer)
            if (n == -1) break
            total += n
            if (total > max) throw BackupException(BackupException.Code.TOO_LARGE)
            out.write(buffer, 0, n)
        }
        return out.toByteArray()
    }

    private fun restoreErrorText(e: Throwable): String = when ((e as? BackupException)?.code) {
        BackupException.Code.TOO_LARGE -> "فایل بیش از حد بزرگ است"
        BackupException.Code.NOT_JSON -> "فایل JSON معتبر نیست"
        BackupException.Code.WRONG_FORMAT -> "این فایل پشتیبان MR91 Wealth نیست"
        BackupException.Code.UNSUPPORTED_VERSION -> "نسخه این پشتیبان پشتیبانی نمی‌شود"
        else -> "ساختار داده‌های پشتیبان معتبر نیست؛ چیزی تغییر نکرد"
    }

    class Factory(private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val app = context.applicationContext
            return AppViewModel(WealthRepository(WealthDb.get(app)), SettingsStore(app)) as T
        }
    }

    private companion object {
        const val DUPLICATE_WINDOW_MS = 120_000L
        const val MAX_ACCOUNTS = 30
    }
}
