package com.mr91.wealth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mr91.wealth.data.Account
import com.mr91.wealth.data.Category
import com.mr91.wealth.data.Transaction
import com.mr91.wealth.domain.*
import com.mr91.wealth.ui.theme.BrandMark
import com.mr91.wealth.ui.theme.LocalMR91Colors

@Composable
fun HomeScreen(vm: AppViewModel) {
    val accounts by vm.accounts.collectAsState()
    val txs by vm.transactions.collectAsState()
    val categories by vm.categories.collectAsState()
    val period by vm.period.collectAsState()
    val reserve = LocalBottomReserve.current
    val today = JalaliCalendar.todayEpochDay()
    val range = Periods.range(period, today)
    val totals = Ledger.totals(accounts, txs, range)
    val previousExpense = Periods.previous(period, today)?.let { Ledger.flow(txs, it).second }
    val byCategory = Ledger.expenseByCategory(txs, range)
    val points = Periods.lastMonths(today, 6).map { r ->
        val (income, expense) = Ledger.flow(txs, r)
        MonthPoint(JalaliCalendar.monthName(JalaliCalendar.fromEpochDay(r.startDay).month), income, expense)
    }
    val categoryName: (String?) -> String? = { id -> categories.nameOfOrNull(id) }

    LazyColumn(
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "header") {
            Row(Modifier.fillMaxWidth().staggeredEntrance(0), verticalAlignment = Alignment.CenterVertically) {
                BrandMark(Modifier.size(width = 52.dp, height = 33.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MR91 Wealth", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("پول شما، شفاف و کاملاً روی دستگاه", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OfflineBadge()
            }
        }
        item(key = "period") {
            Box(Modifier.staggeredEntrance(1)) {
                ChoiceRow(Period.entries, period, { it.label }) { vm.period.value = it }
            }
        }
        item(key = "hero") { HeroCard(totals, accounts.size, Modifier.staggeredEntrance(2)) }
        item(key = "stats") {
            Row(Modifier.fillMaxWidth().staggeredEntrance(3), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile("درآمد", totals.incomeToman, Icons.Filled.TrendingUp, LocalMR91Colors.current.income, Modifier.weight(1f))
                StatTile("هزینه", totals.expenseToman, Icons.Filled.TrendingDown, LocalMR91Colors.current.expense, Modifier.weight(1f))
            }
        }
        item(key = "insights") {
            InsightsCard(totals, byCategory, categoryName, previousExpense, range, Modifier.staggeredEntrance(4))
        }
        item(key = "donut") { DonutCard(byCategory, categoryName, totals.expenseToman, Modifier.staggeredEntrance(5)) }
        item(key = "bars") {
            AppCard(Modifier.staggeredEntrance(6)) {
                SectionHeader("درآمد و هزینه، ۶ ماه اخیر")
                MonthlyBars(points)
            }
        }
        item(key = "recent") { SectionHeader("آخرین تراکنش‌ها") }
        if (txs.isEmpty()) {
            item(key = "empty") {
                EmptyState(Icons.Filled.ReceiptLong, "هنوز تراکنشی ثبت نشده است؛ از تب تراکنش‌ها شروع کنید")
            }
        } else {
            itemsIndexed(txs.take(6), key = { _, t -> t.id }) { i, t ->
                TxRow(
                    t,
                    accounts.nameOf(t.accountId),
                    categories.nameOfOrNull(t.categoryId),
                    Modifier.staggeredEntrance(7 + i),
                    onClick = {},
                )
            }
        }
    }
}

@Composable
private fun HeroCard(totals: Totals, accountCount: Int, modifier: Modifier) {
    val scheme = MaterialTheme.colorScheme
    val digits = LocalPersianDigits.current
    val onHero = scheme.onPrimaryContainer
    val net = totals.netToman
    Box(
        modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.extraLarge)
            .background(Brush.linearGradient(listOf(scheme.primaryContainer, lerp(scheme.primary, scheme.primaryContainer, 0.45f))))
            .padding(24.dp),
    ) {
        Column {
            Text("موجودی کل", style = MaterialTheme.typography.labelLarge, color = onHero.copy(alpha = 0.8f))
            AnimatedMoney(
                totals.balanceToman,
                MaterialTheme.typography.displaySmall.copy(color = onHero, fontWeight = FontWeight.ExtraBold),
            )
            Text(
                "≈ " + Money.compact(totals.balanceToman, digits),
                style = MaterialTheme.typography.bodyLarge,
                color = onHero.copy(alpha = 0.75f),
            )
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(shape = RoundedCornerShape(50), color = onHero.copy(alpha = 0.14f)) {
                    val sign = if (net >= 0) "+" else "−"
                    Text(
                        "جریان دوره: $sign${money(if (net >= 0) net else -net)}",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = onHero,
                    )
                }
                Surface(shape = RoundedCornerShape(50), color = onHero.copy(alpha = 0.14f)) {
                    Text(
                        "${numText(accountCount.toLong())} حساب",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        color = onHero,
                    )
                }
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: Long, icon: ImageVector, tint: Color, modifier: Modifier) {
    AppCard(modifier) {
        Box(Modifier.size(38.dp).background(tint.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(money(value), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun InsightsCard(
    totals: Totals,
    byCategory: List<Pair<String?, Long>>,
    nameOf: (String?) -> String?,
    previousExpense: Long?,
    range: DayRange?,
    modifier: Modifier,
) {
    val colors = LocalMR91Colors.current
    val days = range?.days
    val daily = if (days != null && days > 0) totals.expenseToman / days else null
    val top = byCategory.firstOrNull()
    val change = if (previousExpense != null && previousExpense > 0) {
        (totals.expenseToman - previousExpense) * 100 / previousExpense
    } else {
        null
    }
    AppCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Insights, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(8.dp))
            Text("بینش‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(6.dp))
        InsightLine("میانگین روزانه هزینه", if (daily != null) money(daily) else "—")
        InsightLine(
            "بیشترین هزینه",
            if (top != null) "${nameOf(top.first) ?: "بدون دسته"} · ${money(top.second)}" else "—",
        )
        if (change != null) {
            val up = change > 0
            val sign = if (up) "+" else ""
            InsightLine(
                "نسبت به دوره قبل",
                sign + numText(change) + "٪",
                if (up) colors.expense else colors.income,
            )
        }
    }
}

@Composable
private fun InsightLine(label: String, value: String, valueColor: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold, color = valueColor)
    }
}

@Composable
private fun DonutCard(
    byCategory: List<Pair<String?, Long>>,
    nameOf: (String?) -> String?,
    total: Long,
    modifier: Modifier,
) {
    AppCard(modifier) {
        SectionHeader("سهم دسته‌ها از هزینه")
        if (byCategory.isEmpty()) {
            Text("در این دوره هزینه‌ای ثبت نشده", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val slices = byCategory.mapIndexed { i, pair -> colorAt(i) to pair.second }
            Row(verticalAlignment = Alignment.CenterVertically) {
                DonutChart(slices, Modifier.size(150.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            Money.compact(total, LocalPersianDigits.current),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        Text("هزینه", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Column(Modifier.weight(1f).padding(start = 16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    byCategory.take(5).forEachIndexed { i, pair ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(colorAt(i), CircleShape))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                nameOf(pair.first) ?: "بدون دسته",
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(numText(pair.second * 100 / total) + "٪", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
