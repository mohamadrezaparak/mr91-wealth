package com.mr91.wealth.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mr91.wealth.data.*
import com.mr91.wealth.domain.*
import com.mr91.wealth.ui.theme.LocalMR91Colors
import java.util.UUID

@Composable
fun TransactionsScreen(vm: AppViewModel) {
    val accounts by vm.accounts.collectAsState()
    val categories by vm.categories.collectAsState()
    val txs by vm.transactions.collectAsState()
    val reserve = LocalBottomReserve.current
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf<TxType?>(null) }
    var editing by remember { mutableStateOf<Transaction?>(null) }
    var creating by remember { mutableStateOf(false) }

    val needle = query.trim()
    val filtered = txs.filter { t ->
        (filter == null || t.type.canonical() == filter) &&
            (needle.isEmpty() ||
                t.description.contains(needle, ignoreCase = true) ||
                categories.nameOfOrNull(t.categoryId)?.contains(needle, ignoreCase = true) == true)
    }
    val grouped = filtered.groupBy { JalaliCalendar.epochDayOf(it.occurredAt) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve + 72.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "title") {
                ScreenTitle("تراکنش‌ها", "${numText(filtered.size.toLong())} مورد نمایش داده می‌شود")
            }
            item(key = "search") {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().staggeredEntrance(1),
                    singleLine = true,
                    shape = MaterialTheme.shapes.large,
                    placeholder = { Text("جستجو در شرح یا دسته‌بندی") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "پاک کردن جستجو")
                            }
                        }
                    },
                )
            }
            item(key = "filters") {
                Box(Modifier.staggeredEntrance(2)) {
                    ChoiceRow<TxType?>(
                        listOf(null, TxType.INCOME, TxType.EXPENSE, TxType.TRANSFER),
                        filter,
                        { it?.let(::typeLabel) ?: "همه" },
                    ) { filter = it }
                }
            }
            if (filtered.isEmpty()) {
                item(key = "empty") {
                    EmptyState(
                        Icons.Filled.ReceiptLong,
                        if (txs.isEmpty()) "هنوز تراکنشی ثبت نشده است" else "موردی با این جستجو یا فیلتر پیدا نشد",
                    )
                }
            }
            grouped.forEach { (day, list) ->
                item(key = "day-$day") {
                    Text(
                        JalaliCalendar.format(day, LocalPersianDigits.current),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, start = 4.dp),
                    )
                }
                items(list, key = { it.id }) { t ->
                    TxRow(
                        t,
                        accounts.nameOf(t.accountId),
                        categories.nameOfOrNull(t.categoryId),
                        Modifier.animateItem(),
                    ) { editing = t }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("تراکنش جدید") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = reserve),
        )
    }

    if (creating || editing != null) {
        TransactionEditor(
            initial = editing,
            accounts = accounts,
            categories = categories,
            vm = vm,
            onDismiss = {
                creating = false
                editing = null
            },
        )
    }
}

@Composable
fun TransactionEditor(
    initial: Transaction?,
    accounts: List<Account>,
    categories: List<Category>,
    vm: AppViewModel,
    onDismiss: () -> Unit,
) {
    val digits = LocalPersianDigits.current
    val haptic = LocalHapticFeedback.current
    val draftId = remember { initial?.id ?: UUID.randomUUID().toString() }
    var type by remember { mutableStateOf((initial?.type ?: TxType.EXPENSE).canonical()) }
    var amountText by remember { mutableStateOf(initial?.amountMinor?.toString() ?: "") }
    var accountId by remember { mutableStateOf(initial?.accountId ?: accounts.firstOrNull()?.id ?: "") }
    var toAccountId by remember {
        mutableStateOf(initial?.linkedAccountId ?: accounts.firstOrNull { it.id != accountId }?.id ?: "")
    }
    var categoryId by remember { mutableStateOf(initial?.categoryId) }
    var dateText by remember {
        mutableStateOf(
            JalaliCalendar.format(
                initial?.let { JalaliCalendar.epochDayOf(it.occurredAt) } ?: JalaliCalendar.todayEpochDay(),
                digits,
            )
        )
    }
    var description by remember { mutableStateOf(initial?.description ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var duplicateWarning by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val amount = Money.parse(amountText)
    val amountToman = (amount as? Money.Parsed.Ok)?.toman
    val dateDay = JalaliCalendar.parse(dateText)?.let { JalaliCalendar.toEpochDay(it) }
    val matchingCategories = categories.filter { if (type == TxType.INCOME) it.isIncome else !it.isIncome }
    val isTransfer = type == TxType.TRANSFER
    val canSave = amountToman != null && dateDay != null && accountId.isNotBlank() &&
        (!isTransfer || (toAccountId.isNotBlank() && toAccountId != accountId)) &&
        (isTransfer || categoryId != null)

    fun save() {
        val day = dateDay
        val toman = amountToman
        if (toman == null || day == null) {
            error = "مبلغ یا تاریخ نامعتبر است"
            return
        }
        val draft = TransactionDraft(
            id = draftId,
            type = type,
            amountToman = toman,
            accountId = accountId,
            toAccountId = if (isTransfer) toAccountId else null,
            categoryId = if (isTransfer) null else categoryId,
            occurredAt = occurredAtFor(day, initial),
            description = description.trim(),
        )
        vm.saveTransaction(draft, confirmSimilar = duplicateWarning) { result ->
            when (result) {
                SaveResult.Saved -> {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onDismiss()
                }
                SaveResult.PossibleDuplicate -> duplicateWarning = true
                is SaveResult.Invalid -> error = result.message
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = {
            Text(
                if (initial == null) "تراکنش جدید" else "ویرایش تراکنش",
                fontWeight = FontWeight.Bold,
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ChoiceRow(listOf(TxType.EXPENSE, TxType.INCOME, TxType.TRANSFER), type, { typeLabel(it) }) {
                    type = it
                    categoryId = null
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("مبلغ (تومان)") },
                    singleLine = true,
                    isError = amountText.isNotBlank() && amountToman == null,
                    supportingText = { Text(amountHint(amount, amountText, digits)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("حساب", style = MaterialTheme.typography.labelLarge)
                ChoiceRow(accounts, accounts.firstOrNull { it.id == accountId }, { it.name }) { accountId = it.id }
                if (isTransfer) {
                    Text("حساب مقصد", style = MaterialTheme.typography.labelLarge)
                    ChoiceRow(accounts, accounts.firstOrNull { it.id == toAccountId }, { it.name }) { toAccountId = it.id }
                } else {
                    Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                    ChoiceRow(matchingCategories, matchingCategories.firstOrNull { it.id == categoryId }, { it.name }) {
                        categoryId = it.id
                    }
                }
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("تاریخ شمسی") },
                    singleLine = true,
                    isError = dateDay == null,
                    supportingText = { Text(if (dateDay == null) "مثال: ۱۴۰۳/۰۷/۱۵" else "تاریخ معتبر") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { if (it.length <= 200) description = it },
                    label = { Text("شرح (اختیاری)") },
                    supportingText = { Text("${description.length}/200") },
                    modifier = Modifier.fillMaxWidth(),
                )
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (duplicateWarning) {
                    Text(
                        "این تراکنش شبیه ورودی قبلی است. اگر عمداً دوباره ثبت می‌کنید، دوباره ذخیره را بزنید.",
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (initial != null) {
                    TextButton(onClick = { confirmDelete = true }) {
                        Text("حذف این تراکنش", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { save() }, enabled = canSave) {
                Text(if (duplicateWarning) "ذخیره با وجود شباهت" else "ذخیره")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )

    if (confirmDelete && initial != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف تراکنش؟") },
            text = { Text("تراکنش به سطل زباله می‌رود و از اسنک‌بار می‌توانید آن را برگردانید.") },
            confirmButton = {
                Button(onClick = {
                    vm.deleteTransaction(initial.id)
                    confirmDelete = false
                    onDismiss()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } },
        )
    }
}

private fun amountHint(amount: Money.Parsed, raw: String, digits: Boolean): String = when (amount) {
    is Money.Parsed.Ok -> Money.format(amount.toman, digits)
    is Money.Parsed.Invalid -> if (raw.isBlank()) "فقط عدد صحیح، بدون اعشار" else when (amount.problem) {
        Money.AmountProblem.EMPTY -> "فقط عدد صحیح، بدون اعشار"
        Money.AmountProblem.NOT_NUMERIC -> "فقط رقم وارد کنید"
        Money.AmountProblem.DECIMAL_NOT_ALLOWED -> "تومان اعشار ندارد"
        Money.AmountProblem.ZERO -> "مبلغ باید بیشتر از صفر باشد"
        Money.AmountProblem.NEGATIVE -> "مبلغ منفی مجاز نیست"
        Money.AmountProblem.TOO_LARGE -> "مبلغ بیش از حد مجاز است"
    }
}

/** Keeps the original time of an edited transaction when its day did not change. */
private fun occurredAtFor(day: Long, initial: Transaction?): Long =
    if (initial != null && JalaliCalendar.epochDayOf(initial.occurredAt) == day) initial.occurredAt
    else JalaliCalendar.millisForDay(day)

@Composable
fun BudgetsScreen(vm: AppViewModel) {
    val budgets by vm.budgets.collectAsState()
    val txs by vm.transactions.collectAsState()
    val categories by vm.categories.collectAsState()
    val reserve = LocalBottomReserve.current
    val today = JalaliCalendar.todayEpochDay()
    val monthName = JalaliCalendar.monthName(JalaliCalendar.fromEpochDay(today).month)
    val current = budgets.filter { today in DayRange(it.startEpochDay, it.endEpochDay) }
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve + 72.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "title") {
                ScreenTitle("بودجه $monthName", "مصرف از تراکنش‌های واقعی محاسبه می‌شود")
            }
            if (current.isEmpty()) {
                item(key = "empty") {
                    EmptyState(Icons.Filled.ReceiptLong, "برای این ماه بودجه‌ای تعریف نشده است")
                }
            }
            itemsIndexed(current, key = { _, b -> b.id }) { i, b ->
                BudgetCard(b, Ledger.spentFor(b, txs), Modifier.staggeredEntrance(i)) { vm.deleteBudget(b.id) }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("بودجه جدید") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = reserve),
        )
    }

    if (creating) {
        BudgetDialog(
            categories = categories.filterNot { it.isIncome },
            onDismiss = { creating = false },
            onSave = { categoryId, limit ->
                vm.saveBudget(categoryId, limit)
                creating = false
            },
        )
    }
}

@Composable
fun BudgetCard(b: Budget, spent: Long, modifier: Modifier, onDelete: () -> Unit) {
    val digits = LocalPersianDigits.current
    val colors = LocalMR91Colors.current
    val progress = Ledger.progress(b.amountMinor.coerceAtLeast(1L), spent.coerceAtLeast(0L))
    val color = when (progress.state) {
        BudgetState.ON_TRACK -> MaterialTheme.colorScheme.primary
        BudgetState.WARNING -> colors.warning
        BudgetState.REACHED, BudgetState.OVERSPENT -> colors.expense
    }
    val percentDigits = progress.percent.coerceAtMost(999).toString()
    val percentText = if (digits) Money.toPersianDigits(percentDigits) else percentDigits
    AppCard(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(b.name, fontWeight = FontWeight.SemiBold)
            Text("$percentText٪", color = color, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress.percent.coerceAtMost(100) / 100f },
            modifier = Modifier.fillMaxWidth().height(10.dp),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
        Spacer(Modifier.height(10.dp))
        Text("مصرف ${money(progress.spentToman)} از ${money(progress.limitToman)}")
        val remainingText = if (progress.remainingToman >= 0) {
            "مانده: ${money(progress.remainingToman)}"
        } else {
            "بیش از بودجه: ${money(-progress.remainingToman)}"
        }
        Text(remainingText, color = color)
        TextButton(onClick = onDelete, modifier = Modifier.align(Alignment.End)) { Text("حذف") }
    }
}

@Composable
fun BudgetDialog(categories: List<Category>, onDismiss: () -> Unit, onSave: (String?, Long) -> Unit) {
    var categoryId by remember { mutableStateOf<String?>(null) }
    var limitText by remember { mutableStateOf("") }
    val limit = (Money.parse(limitText) as? Money.Parsed.Ok)?.toman
    val options: List<String?> = listOf<String?>(null) + categories.map { it.id }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text("بودجه این ماه", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("دسته‌بندی", style = MaterialTheme.typography.labelLarge)
                ChoiceRow(options, categoryId, { id -> categories.nameOfOrNull(id) ?: "همه هزینه‌ها" }) {
                    categoryId = it
                }
                OutlinedTextField(
                    value = limitText,
                    onValueChange = { limitText = it },
                    label = { Text("سقف بودجه (تومان)") },
                    singleLine = true,
                    isError = limitText.isNotBlank() && limit == null,
                    supportingText = { Text(limit?.let { money(it) } ?: "عدد صحیح و مثبت") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(categoryId, limit ?: 0L) }, enabled = limit != null) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
