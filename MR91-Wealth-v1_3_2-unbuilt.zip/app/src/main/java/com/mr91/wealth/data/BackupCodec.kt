package com.mr91.wealth.data

import com.mr91.wealth.domain.Money
import org.json.JSONArray
import org.json.JSONObject

data class BackupSnapshot(
    val accounts: List<Account>,
    val categories: List<Category>,
    val transactions: List<Transaction>,
    val budgets: List<Budget>,
    val groups: List<ExpenseGroup>,
    val members: List<GroupMember>,
    val expenses: List<SharedExpense>,
    val shares: List<ExpenseShare>,
    val settlements: List<Settlement>,
) {
    val transactionCount: Int get() = transactions.count { it.deletedAt == null }
}

class BackupException(val code: Code, detail: String = "") : Exception("$code: $detail") {
    enum class Code { TOO_LARGE, NOT_JSON, WRONG_FORMAT, UNSUPPORTED_VERSION, INVALID_DATA }
}

/**
 * Versioned JSON backup format. Encoding and decoding are symmetrical, and decoding validates the whole
 * file before anything is written, so a damaged file can never wipe existing data.
 */
object BackupCodec {
    const val FORMAT = "mr91-wealth-backup"
    const val VERSION = 2
    const val MAX_BYTES = 5L * 1024 * 1024
    private const val MAX_ROWS = 50_000
    private const val MAX_TEXT = 500

    fun encode(s: BackupSnapshot, exportedAtMillis: Long): String {
        val root = JSONObject()
            .put("format", FORMAT)
            .put("backupVersion", VERSION)
            .put("exportedAt", exportedAtMillis)
            .put("accounts", JSONArray(s.accounts.map { a ->
                JSONObject().put("id", a.id).put("name", a.name).put("type", a.type.name)
                    .put("currency", a.currency).put("openingMinor", a.openingMinor)
                    .put("archived", a.archived).put("createdAt", a.createdAt)
                    .put("targetMinor", a.targetMinor ?: JSONObject.NULL)
                    .put("colorArgb", a.colorArgb ?: JSONObject.NULL)
            }))
            .put("categories", JSONArray(s.categories.map { c ->
                JSONObject().put("id", c.id).put("name", c.name).put("isIncome", c.isIncome).put("archived", c.archived)
            }))
            .put("transactions", JSONArray(s.transactions.map { t ->
                JSONObject().put("id", t.id).put("amountMinor", t.amountMinor).put("currency", t.currency)
                    .put("type", t.type.name).put("accountId", t.accountId)
                    .put("categoryId", t.categoryId ?: JSONObject.NULL)
                    .put("occurredAt", t.occurredAt).put("description", t.description)
                    .put("merchant", t.merchant ?: JSONObject.NULL).put("notes", t.notes ?: JSONObject.NULL)
                    .put("linkedAccountId", t.linkedAccountId ?: JSONObject.NULL)
                    .put("createdAt", t.createdAt).put("updatedAt", t.updatedAt)
                    .put("deletedAt", t.deletedAt ?: JSONObject.NULL)
            }))
            .put("budgets", JSONArray(s.budgets.map { b ->
                JSONObject().put("id", b.id).put("name", b.name).put("amountMinor", b.amountMinor)
                    .put("startEpochDay", b.startEpochDay).put("endEpochDay", b.endEpochDay)
                    .put("categoryId", b.categoryId ?: JSONObject.NULL).put("rollover", b.rollover)
            }))
            .put("groups", JSONArray(s.groups.map { g ->
                JSONObject().put("id", g.id).put("name", g.name).put("createdAt", g.createdAt)
            }))
            .put("members", JSONArray(s.members.map { m ->
                JSONObject().put("id", m.id).put("groupId", m.groupId).put("name", m.name)
            }))
            .put("expenses", JSONArray(s.expenses.map { e ->
                JSONObject().put("id", e.id).put("groupId", e.groupId).put("title", e.title)
                    .put("amountMinor", e.amountMinor).put("payerId", e.payerId)
                    .put("occurredAt", e.occurredAt).put("createdAt", e.createdAt)
                    .put("deletedAt", e.deletedAt ?: JSONObject.NULL)
            }))
            .put("shares", JSONArray(s.shares.map { x ->
                JSONObject().put("expenseId", x.expenseId).put("memberId", x.memberId).put("amountMinor", x.amountMinor)
            }))
            .put("settlements", JSONArray(s.settlements.map { x ->
                JSONObject().put("id", x.id).put("groupId", x.groupId).put("fromMemberId", x.fromMemberId)
                    .put("toMemberId", x.toMemberId).put("amountMinor", x.amountMinor).put("settledAt", x.settledAt)
            }))
        return root.toString(2)
    }

    fun decode(bytes: ByteArray): BackupSnapshot {
        if (bytes.size > MAX_BYTES) throw BackupException(BackupException.Code.TOO_LARGE)
        val root = try {
            JSONObject(String(bytes, Charsets.UTF_8))
        } catch (e: Exception) {
            throw BackupException(BackupException.Code.NOT_JSON)
        }
        if (root.optString("format") != FORMAT) throw BackupException(BackupException.Code.WRONG_FORMAT)
        if (root.optInt("backupVersion", -1) != VERSION) throw BackupException(BackupException.Code.UNSUPPORTED_VERSION)
        val snapshot = try {
            parse(root)
        } catch (e: BackupException) {
            throw e
        } catch (e: Exception) {
            throw BackupException(BackupException.Code.INVALID_DATA, e.javaClass.simpleName)
        }
        validate(snapshot)
        return snapshot
    }

    private fun parse(root: JSONObject): BackupSnapshot = BackupSnapshot(
        accounts = root.rows("accounts").map { o ->
            Account(
                id = o.getString("id"), name = o.getString("name"),
                type = AccountType.valueOf(o.getString("type")), currency = o.getString("currency"),
                openingMinor = o.getLong("openingMinor"), archived = o.getBoolean("archived"),
                createdAt = o.getLong("createdAt"),
                targetMinor = o.longOrNull("targetMinor"), colorArgb = o.longOrNull("colorArgb"),
            )
        },
        categories = root.rows("categories").map { o ->
            Category(o.getString("id"), o.getString("name"), o.getBoolean("isIncome"), o.getBoolean("archived"))
        },
        transactions = root.rows("transactions").map { o ->
            Transaction(
                id = o.getString("id"), amountMinor = o.getLong("amountMinor"), currency = o.getString("currency"),
                type = TxType.valueOf(o.getString("type")), accountId = o.getString("accountId"),
                categoryId = o.strOrNull("categoryId"), occurredAt = o.getLong("occurredAt"),
                description = o.getString("description"), merchant = o.strOrNull("merchant"),
                notes = o.strOrNull("notes"), linkedAccountId = o.strOrNull("linkedAccountId"),
                createdAt = o.getLong("createdAt"), updatedAt = o.getLong("updatedAt"),
                deletedAt = o.longOrNull("deletedAt"),
            )
        },
        budgets = root.rows("budgets").map { o ->
            Budget(
                id = o.getString("id"), name = o.getString("name"), amountMinor = o.getLong("amountMinor"),
                startEpochDay = o.getLong("startEpochDay"), endEpochDay = o.getLong("endEpochDay"),
                categoryId = o.strOrNull("categoryId"), rollover = o.getBoolean("rollover"),
            )
        },
        groups = root.rows("groups").map { o -> ExpenseGroup(o.getString("id"), o.getString("name"), o.getLong("createdAt")) },
        members = root.rows("members").map { o -> GroupMember(o.getString("id"), o.getString("groupId"), o.getString("name")) },
        expenses = root.rows("expenses").map { o ->
            SharedExpense(
                id = o.getString("id"), groupId = o.getString("groupId"), title = o.getString("title"),
                amountMinor = o.getLong("amountMinor"), payerId = o.getString("payerId"),
                occurredAt = o.getLong("occurredAt"), createdAt = o.getLong("createdAt"),
                deletedAt = o.longOrNull("deletedAt"),
            )
        },
        shares = root.rows("shares").map { o ->
            ExpenseShare(o.getString("expenseId"), o.getString("memberId"), o.getLong("amountMinor"))
        },
        settlements = root.rows("settlements").map { o ->
            Settlement(
                id = o.getString("id"), groupId = o.getString("groupId"), fromMemberId = o.getString("fromMemberId"),
                toMemberId = o.getString("toMemberId"), amountMinor = o.getLong("amountMinor"),
                settledAt = o.getLong("settledAt"),
            )
        },
    )

    private fun validate(s: BackupSnapshot) {
        fun fail(why: String): Nothing = throw BackupException(BackupException.Code.INVALID_DATA, why)
        fun ensure(ok: Boolean, why: String) { if (!ok) fail(why) }
        fun unique(ids: List<String>, table: String) = ensure(ids.size == ids.toSet().size, "duplicate id in $table")
        fun idsOk(ids: List<String>, table: String) = ensure(ids.all { it.isNotBlank() && it.length <= 64 }, "bad id in $table")
        fun amountOk(v: Long, table: String) = ensure(v in 1..Money.MAX_TOMAN, "amount out of range in $table")

        unique(s.accounts.map { it.id }, "accounts"); idsOk(s.accounts.map { it.id }, "accounts")
        unique(s.categories.map { it.id }, "categories"); idsOk(s.categories.map { it.id }, "categories")
        unique(s.transactions.map { it.id }, "transactions"); idsOk(s.transactions.map { it.id }, "transactions")
        unique(s.budgets.map { it.id }, "budgets")
        unique(s.groups.map { it.id }, "groups")
        unique(s.members.map { it.id }, "members")
        unique(s.expenses.map { it.id }, "expenses")
        unique(s.settlements.map { it.id }, "settlements")
        unique(s.shares.map { it.expenseId + "|" + it.memberId }, "shares")

        val accountIds = s.accounts.map { it.id }.toSet()
        val categoryIds = s.categories.map { it.id }.toSet()
        s.accounts.forEach { a ->
            ensure(a.name.isNotBlank() && a.name.length <= 120, "bad account name")
            ensure(a.openingMinor in -Money.MAX_TOMAN..Money.MAX_TOMAN, "opening balance out of range")
            ensure(a.targetMinor == null || a.targetMinor in 1..Money.MAX_TOMAN, "goal out of range")
        }
        s.transactions.forEach { t ->
            // 0 is allowed: rows migrated from cents can round down to zero toman.
            ensure(t.amountMinor in 0..Money.MAX_TOMAN, "transaction amount out of range")
            ensure(t.description.length <= MAX_TEXT, "description too long")
            ensure(t.accountId in accountIds, "transaction points to a missing account")
            ensure(t.categoryId == null || t.categoryId in categoryIds, "transaction points to a missing category")
            if (t.type.canonical() == TxType.TRANSFER) {
                ensure(t.linkedAccountId != null && t.linkedAccountId in accountIds && t.linkedAccountId != t.accountId,
                    "transfer destination is invalid")
            }
        }
        s.budgets.forEach { b ->
            amountOk(b.amountMinor, "budgets")
            ensure(b.startEpochDay <= b.endEpochDay, "budget period is reversed")
            ensure(b.categoryId == null || b.categoryId in categoryIds, "budget points to a missing category")
        }

        val groupIds = s.groups.map { it.id }.toSet()
        val memberGroup = s.members.associate { it.id to it.groupId }
        ensure(s.members.all { it.groupId in groupIds }, "member points to a missing group")
        s.expenses.forEach { e ->
            amountOk(e.amountMinor, "expenses")
            ensure(e.groupId in groupIds, "expense points to a missing group")
            ensure(memberGroup[e.payerId] == e.groupId, "payer is not in the expense group")
        }
        val expenseById = s.expenses.associateBy { it.id }
        s.shares.forEach { x ->
            ensure(x.amountMinor >= 0, "negative share")
            val expense = expenseById[x.expenseId] ?: fail("share points to a missing expense")
            ensure(memberGroup[x.memberId] == expense.groupId, "share member is not in the expense group")
        }
        s.expenses.forEach { e ->
            val total = s.shares.filter { it.expenseId == e.id }.sumOf { it.amountMinor }
            ensure(total == e.amountMinor, "shares do not add up to the expense amount")
        }
        s.settlements.forEach { st ->
            amountOk(st.amountMinor, "settlements")
            ensure(st.groupId in groupIds, "settlement points to a missing group")
            ensure(memberGroup[st.fromMemberId] == st.groupId && memberGroup[st.toMemberId] == st.groupId,
                "settlement member is not in the group")
            ensure(st.fromMemberId != st.toMemberId, "settlement to the same person")
        }
    }

    private fun JSONObject.rows(key: String): List<JSONObject> {
        val array = getJSONArray(key)
        if (array.length() > MAX_ROWS) throw BackupException(BackupException.Code.INVALID_DATA, "too many rows in $key")
        return List(array.length()) { array.getJSONObject(it) }
    }

    private fun JSONObject.strOrNull(key: String): String? = if (isNull(key)) null else getString(key)
    private fun JSONObject.longOrNull(key: String): Long? = if (isNull(key)) null else getLong(key)
}
