package com.mr91.wealth.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.mr91.wealth.domain.Money

/** INCOME, EXPENSE and TRANSFER are the only types written by the app. DEBT_PAYMENT and SHARED_EXPENSE exist only for rows created by schema v1 and are read as EXPENSE. */
enum class TxType {
    INCOME, EXPENSE, TRANSFER, DEBT_PAYMENT, SHARED_EXPENSE;

    fun canonical(): TxType = if (this == INCOME || this == TRANSFER) this else EXPENSE
}

enum class AccountType { CASH, BANK, SAVINGS, CREDIT, CUSTOM }

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey val id: String,
    val name: String,
    val type: AccountType,
    val currency: String = Money.CURRENCY_CODE,
    val openingMinor: Long = 0,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    /** Optional savings goal in toman. */
    val targetMinor: Long? = null,
    /** Optional accent color as ARGB. */
    val colorArgb: Long? = null,
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val id: String,
    val name: String,
    val isIncome: Boolean,
    val archived: Boolean = false,
)

@Entity(tableName = "transactions", indices = [Index("accountId"), Index("occurredAt")])
data class Transaction(
    @PrimaryKey val id: String,
    val amountMinor: Long,
    val currency: String,
    val type: TxType,
    val accountId: String,
    val categoryId: String?,
    val occurredAt: Long,
    val description: String,
    val merchant: String? = null,
    val notes: String? = null,
    val linkedAccountId: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    /** Soft delete: non-null means the row is in the trash and can be restored. */
    val deletedAt: Long? = null,
)

/** categoryId == null means "all expenses". */
@Entity(tableName = "budgets")
data class Budget(
    @PrimaryKey val id: String,
    val name: String,
    val amountMinor: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val categoryId: String? = null,
    val rollover: Boolean = false,
)

@Entity(tableName = "expense_groups")
data class ExpenseGroup(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
)

@Entity(tableName = "group_members")
data class GroupMember(
    @PrimaryKey val id: String,
    val groupId: String,
    val name: String,
)

@Entity(tableName = "shared_expenses")
data class SharedExpense(
    @PrimaryKey val id: String,
    val groupId: String,
    val title: String,
    val amountMinor: Long,
    val payerId: String,
    val occurredAt: Long,
    val createdAt: Long,
    val deletedAt: Long? = null,
)

@Entity(tableName = "expense_shares", primaryKeys = ["expenseId", "memberId"])
data class ExpenseShare(
    val expenseId: String,
    val memberId: String,
    val amountMinor: Long,
)

@Entity(tableName = "settlements")
data class Settlement(
    @PrimaryKey val id: String,
    val groupId: String,
    val fromMemberId: String,
    val toMemberId: String,
    val amountMinor: Long,
    val settledAt: Long,
)
