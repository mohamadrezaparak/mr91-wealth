package com.mr91.wealth.domain

import java.time.LocalDate

enum class Period(val label: String) {
    TODAY("امروز"), WEEK("این هفته"), MONTH("این ماه"), YEAR("امسال"), ALL("همه")
}

/** Inclusive range of epoch days. */
data class DayRange(val startDay: Long, val endDay: Long) {
    val days: Long get() = endDay - startDay + 1

    operator fun contains(epochDay: Long): Boolean = epochDay in startDay..endDay
}

object Periods {
    /** Persian week starts on Saturday. Returns null for [Period.ALL] meaning "no filter". */
    fun range(period: Period, todayDay: Long): DayRange? {
        val today = JalaliCalendar.fromEpochDay(todayDay)
        val start = when (period) {
            Period.TODAY -> todayDay
            Period.WEEK -> todayDay - ((LocalDate.ofEpochDay(todayDay).dayOfWeek.value - 6 + 7) % 7)
            Period.MONTH -> todayDay - (today.day - 1)
            Period.YEAR -> todayDay - (JalaliCalendar.dayOfYear(today) - 1)
            Period.ALL -> return null
        }
        return DayRange(start, todayDay)
    }

    fun monthRange(todayDay: Long): DayRange {
        val today = JalaliCalendar.fromEpochDay(todayDay)
        val start = todayDay - (today.day - 1)
        return DayRange(start, start + JalaliCalendar.daysInMonth(today.year, today.month) - 1)
    }

    /** The last [count] Jalali months, oldest first, ending with the month that contains [todayDay]. */
    fun lastMonths(todayDay: Long, count: Int): List<DayRange> {
        val t = JalaliCalendar.fromEpochDay(todayDay)
        val currentIndex = t.year * 12 + (t.month - 1)
        return ((count - 1) downTo 0).map { back ->
            val index = currentIndex - back
            val year = index / 12
            val month = index % 12 + 1
            val start = JalaliCalendar.toEpochDay(JalaliDate(year, month, 1))
            DayRange(start, start + JalaliCalendar.daysInMonth(year, month) - 1)
        }
    }

    /** The comparison window for the same period: yesterday, last week, last Jalali month, last Jalali year. */
    fun previous(period: Period, todayDay: Long): DayRange? {
        val current = range(period, todayDay) ?: return null
        return when (period) {
            Period.TODAY -> DayRange(todayDay - 1, todayDay - 1)
            Period.WEEK -> DayRange(current.startDay - 7, current.startDay - 1)
            Period.MONTH -> lastMonths(todayDay, 2).first()
            Period.YEAR -> {
                val lastYear = JalaliCalendar.fromEpochDay(todayDay).year - 1
                DayRange(JalaliCalendar.toEpochDay(JalaliDate(lastYear, 1, 1)), current.startDay - 1)
            }
            Period.ALL -> null
        }
    }
}
