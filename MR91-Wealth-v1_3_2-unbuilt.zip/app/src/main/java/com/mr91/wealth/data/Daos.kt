package com.mr91.wealth.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts WHERE archived = 0 ORDER BY name")
    fun observe(): Flow<List<Account>>

    @Query("SELECT * FROM accounts")
    suspend fun all(): List<Account>

    @Query("SELECT COUNT(*) FROM accounts")
    suspend fun count(): Int

    @Upsert
    suspend fun upsert(account: Account)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories WHERE archived = 0 ORDER BY name")
    fun observe(): Flow<List<Category>>

    @Query("SELECT * FROM categories")
    suspend fun all(): List<Category>

    @Upsert
    suspend fun upsert(category: Category)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE deletedAt IS NULL ORDER BY occurredAt DESC, createdAt DESC")
    fun observeActive(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions")
    suspend fun all(): List<Transaction>

    @Upsert
    suspend fun upsert(transaction: Transaction)

    @Query("UPDATE transactions SET deletedAt = :at, updatedAt = :at WHERE id = :id")
    suspend fun markDeleted(id: String, at: Long): Int

    @Query("UPDATE transactions SET deletedAt = NULL, updatedAt = :at WHERE id = :id")
    suspend fun restore(id: String, at: Long): Int
}

@Dao
interface BudgetDao {
    @Query("SELECT * FROM budgets ORDER BY startEpochDay DESC")
    fun observe(): Flow<List<Budget>>

    @Query("SELECT * FROM budgets")
    suspend fun all(): List<Budget>

    @Upsert
    suspend fun upsert(budget: Budget)

    @Query("DELETE FROM budgets WHERE id = :id")
    suspend fun delete(id: String)
}

@Dao
interface GroupDao {
    @Query("SELECT * FROM expense_groups ORDER BY createdAt DESC")
    fun observeGroups(): Flow<List<ExpenseGroup>>

    @Query("SELECT * FROM group_members")
    fun observeMembers(): Flow<List<GroupMember>>

    @Query("SELECT * FROM shared_expenses WHERE deletedAt IS NULL ORDER BY occurredAt DESC")
    fun observeExpenses(): Flow<List<SharedExpense>>

    @Query("SELECT s.* FROM expense_shares s INNER JOIN shared_expenses e ON s.expenseId = e.id WHERE e.deletedAt IS NULL")
    fun observeShares(): Flow<List<ExpenseShare>>

    @Query("SELECT * FROM settlements ORDER BY settledAt DESC")
    fun observeSettlements(): Flow<List<Settlement>>

    @Query("SELECT * FROM expense_groups")
    suspend fun allGroups(): List<ExpenseGroup>

    @Query("SELECT * FROM group_members")
    suspend fun allMembers(): List<GroupMember>

    @Query("SELECT * FROM shared_expenses")
    suspend fun allExpenses(): List<SharedExpense>

    @Query("SELECT * FROM expense_shares")
    suspend fun allShares(): List<ExpenseShare>

    @Query("SELECT * FROM settlements")
    suspend fun allSettlements(): List<Settlement>

    @Upsert
    suspend fun upsertGroup(group: ExpenseGroup)

    @Upsert
    suspend fun upsertMember(member: GroupMember)

    @Upsert
    suspend fun upsertExpense(expense: SharedExpense)

    @Upsert
    suspend fun upsertShares(shares: List<ExpenseShare>)

    @Upsert
    suspend fun upsertSettlement(settlement: Settlement)

    @Query("UPDATE shared_expenses SET deletedAt = :at WHERE id = :id")
    suspend fun markExpenseDeleted(id: String, at: Long): Int

    @Query("UPDATE shared_expenses SET deletedAt = NULL WHERE id = :id")
    suspend fun restoreExpense(id: String): Int

    @Query("DELETE FROM expense_shares WHERE expenseId IN (SELECT id FROM shared_expenses WHERE groupId = :groupId)")
    suspend fun deleteSharesOfGroup(groupId: String)

    @Query("DELETE FROM shared_expenses WHERE groupId = :groupId")
    suspend fun deleteExpensesOfGroup(groupId: String)

    @Query("DELETE FROM settlements WHERE groupId = :groupId")
    suspend fun deleteSettlementsOfGroup(groupId: String)

    @Query("DELETE FROM group_members WHERE groupId = :groupId")
    suspend fun deleteMembersOfGroup(groupId: String)

    @Query("DELETE FROM expense_groups WHERE id = :groupId")
    suspend fun deleteGroup(groupId: String)
}

/** Used only by restore: clears every table and inserts a validated snapshot inside one transaction. */
@Dao
interface BackupDao {
    @Query("DELETE FROM expense_shares") suspend fun clearShares()
    @Query("DELETE FROM shared_expenses") suspend fun clearExpenses()
    @Query("DELETE FROM settlements") suspend fun clearSettlements()
    @Query("DELETE FROM group_members") suspend fun clearMembers()
    @Query("DELETE FROM expense_groups") suspend fun clearGroups()
    @Query("DELETE FROM transactions") suspend fun clearTransactions()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Query("DELETE FROM categories") suspend fun clearCategories()
    @Query("DELETE FROM accounts") suspend fun clearAccounts()

    @Insert suspend fun insertAccounts(rows: List<Account>)
    @Insert suspend fun insertCategories(rows: List<Category>)
    @Insert suspend fun insertTransactions(rows: List<Transaction>)
    @Insert suspend fun insertBudgets(rows: List<Budget>)
    @Insert suspend fun insertGroups(rows: List<ExpenseGroup>)
    @Insert suspend fun insertMembers(rows: List<GroupMember>)
    @Insert suspend fun insertExpenses(rows: List<SharedExpense>)
    @Insert suspend fun insertShares(rows: List<ExpenseShare>)
    @Insert suspend fun insertSettlements(rows: List<Settlement>)
}
