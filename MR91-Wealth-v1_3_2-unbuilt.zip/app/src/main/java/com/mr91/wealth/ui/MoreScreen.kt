package com.mr91.wealth.ui

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mr91.wealth.BuildConfig
import com.mr91.wealth.ui.theme.Accent
import com.mr91.wealth.ui.theme.LocalMR91Colors

@Composable
fun MoreScreen(vm: AppViewModel, onOpenAccounts: () -> Unit) {
    val settings by vm.settings.collectAsState()
    val pending by vm.pendingRestore.collectAsState()
    val context = LocalContext.current
    val reserve = LocalBottomReserve.current

    val exportJson = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> if (uri != null) vm.exportJson(context.contentResolver, uri) }

    val exportCsv = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv"),
    ) { uri -> if (uri != null) vm.exportCsv(context.contentResolver, uri) }

    val importJson = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.prepareRestore(context.contentResolver, uri) }

    LazyColumn(
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "title") { ScreenTitle("بیشتر", "تنظیمات، حساب‌ها و پشتیبان") }

        item(key = "accounts") {
            NavTile("حساب‌ها و اهداف پس‌انداز", "موجودی هر حساب و پیشرفت هدف‌ها", Icons.Filled.AccountBalanceWallet, onOpenAccounts)
        }

        item(key = "appearance") {
            AppCard(Modifier.staggeredEntrance(1)) {
                SectionTitle(Icons.Filled.Palette, "ظاهر")
                Text("رنگ اصلی", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                AccentPicker(settings.accent, enabled = !settings.dynamicColor) { vm.updateSettings(settings.copy(accent = it)) }
                ChoiceRow(ThemeMode.entries, settings.theme, { themeLabel(it) }) {
                    vm.updateSettings(settings.copy(theme = it))
                }
                SwitchRow(
                    "نمایش ارقام فارسی",
                    settings.persianDigits,
                ) { vm.updateSettings(settings.copy(persianDigits = it)) }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    SwitchRow(
                        "رنگ‌های پویای سیستم",
                        settings.dynamicColor,
                    ) { vm.updateSettings(settings.copy(dynamicColor = it)) }
                }
            }
        }

        item(key = "backup") {
            AppCard(Modifier.staggeredEntrance(2)) {
                SectionTitle(Icons.Filled.Backup, "پشتیبان و خروجی")
                Text(
                    "فایل‌ها روی همین دستگاه ساخته می‌شوند و هیچ‌جا ارسال نمی‌شوند. پشتیبان JSON بدون رمز است؛ آن را در جای امن نگه دارید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = { exportJson.launch("mr91-wealth-backup.json") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Download, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("ذخیره پشتیبان JSON")
                }
                OutlinedButton(onClick = { importJson.launch(arrayOf("application/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Upload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("بازیابی از فایل")
                }
                OutlinedButton(onClick = { exportCsv.launch("mr91-transactions.csv") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.TableChart, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("خروجی CSV برای اکسل")
                }
            }
        }

        item(key = "privacy") {
            AppCard(Modifier.staggeredEntrance(3)) {
                SectionTitle(Icons.Filled.CloudOff, "حریم خصوصی")
                Text(
                    "برنامه بدون اینترنت کار می‌کند. هیچ داده‌ای به سرور ارسال نمی‌شود و بک‌آپ خودکار سیستم برای داده‌های مالی غیرفعال است.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        item(key = "about") {
            AppCard(Modifier.staggeredEntrance(4)) {
                SectionTitle(Icons.Filled.Tune, "درباره")
                Text("نسخه ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
                Text("واحد پول: تومان · مبالغ بدون اعشار", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    pending?.let { snapshot ->
        AlertDialog(
            onDismissRequest = { vm.cancelRestore() },
            shape = MaterialTheme.shapes.extraLarge,
            title = { Text("بازیابی پشتیبان", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "این پشتیبان ${snapshot.transactionCount} تراکنش فعال و ${snapshot.groups.size} گروه دارد. " +
                        "با تأیید، همه داده‌های فعلی جایگزین می‌شوند.",
                )
            },
            confirmButton = { Button(onClick = { vm.confirmRestore() }) { Text("جایگزین کن") } },
            dismissButton = { TextButton(onClick = { vm.cancelRestore() }) { Text("انصراف") } },
        )
    }
}

@Composable
private fun SectionTitle(icon: ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(8.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NavTile(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Filled.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun AccentPicker(selected: Accent, enabled: Boolean, onSelect: (Accent) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Accent.entries.forEach { accent ->
            val ring by animateColorAsState(
                if (accent == selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                label = "accentRing",
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .border(3.dp, ring, CircleShape)
                        .padding(5.dp)
                        .background(accent.color, CircleShape)
                        .clickable(enabled = enabled) { onSelect(accent) },
                )
                Text(accent.label, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun themeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.SYSTEM -> "سیستم"
    ThemeMode.LIGHT -> "روشن"
    ThemeMode.DARK -> "تیره"
}
