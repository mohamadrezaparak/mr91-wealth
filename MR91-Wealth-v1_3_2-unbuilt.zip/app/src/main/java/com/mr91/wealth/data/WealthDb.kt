package com.mr91.wealth.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Account::class, Category::class, Transaction::class, Budget::class,
        ExpenseGroup::class, GroupMember::class, SharedExpense::class, ExpenseShare::class, Settlement::class,
    ],
    version = 3,
    exportSchema = true,
)
@TypeConverters(WealthConverters::class)
abstract class WealthDb : RoomDatabase() {
    abstract fun accounts(): AccountDao
    abstract fun categories(): CategoryDao
    abstract fun transactions(): TransactionDao
    abstract fun budgets(): BudgetDao
    abstract fun groups(): GroupDao
    abstract fun backup(): BackupDao

    companion object {
        @Volatile
        private var instance: WealthDb? = null

        fun get(context: Context): WealthDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(context.applicationContext, WealthDb::class.java, "mr91_wealth.db")
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { instance = it }
            }
    }
}

/**
 * v1 -> v2. Version 1 stored money in cents (x100); from v2 every amount is whole toman.
 * Existing amounts are converted with rounding, so 12.50 units becomes 13 toman and nothing is 100x too large.
 */
val MIGRATION_1_2: Migration = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("UPDATE `accounts` SET `openingMinor` = CAST(ROUND(`openingMinor` / 100.0) AS INTEGER), `currency` = 'IRT'")
        db.execSQL("UPDATE `transactions` SET `amountMinor` = CAST(ROUND(`amountMinor` / 100.0) AS INTEGER), `currency` = 'IRT'")
        db.execSQL("UPDATE `budgets` SET `amountMinor` = MAX(1, CAST(ROUND(`amountMinor` / 100.0) AS INTEGER))")
        db.execSQL("ALTER TABLE `transactions` ADD COLUMN `deletedAt` INTEGER")
        db.execSQL("DROP TABLE IF EXISTS `goals`")
        db.execSQL("DROP TABLE IF EXISTS `debts`")
        db.execSQL("DROP TABLE IF EXISTS `recurring_templates`")
        db.execSQL("CREATE TABLE IF NOT EXISTS `expense_groups` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS `group_members` (`id` TEXT NOT NULL, `groupId` TEXT NOT NULL, `name` TEXT NOT NULL, PRIMARY KEY(`id`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS `shared_expenses` (`id` TEXT NOT NULL, `groupId` TEXT NOT NULL, `title` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `payerId` TEXT NOT NULL, `occurredAt` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `deletedAt` INTEGER, PRIMARY KEY(`id`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS `expense_shares` (`expenseId` TEXT NOT NULL, `memberId` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, PRIMARY KEY(`expenseId`, `memberId`))")
        db.execSQL("CREATE TABLE IF NOT EXISTS `settlements` (`id` TEXT NOT NULL, `groupId` TEXT NOT NULL, `fromMemberId` TEXT NOT NULL, `toMemberId` TEXT NOT NULL, `amountMinor` INTEGER NOT NULL, `settledAt` INTEGER NOT NULL, PRIMARY KEY(`id`))")
    }
}

/** v2 -> v3: savings goal and account color. */
val MIGRATION_2_3: Migration = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `accounts` ADD COLUMN `targetMinor` INTEGER")
        db.execSQL("ALTER TABLE `accounts` ADD COLUMN `colorArgb` INTEGER")
    }
}

class WealthConverters {
    @TypeConverter fun txTypeToString(value: TxType): String = value.name
    @TypeConverter fun stringToTxType(value: String): TxType =
        runCatching { TxType.valueOf(value) }.getOrDefault(TxType.EXPENSE)

    @TypeConverter fun accountTypeToString(value: AccountType): String = value.name
    @TypeConverter fun stringToAccountType(value: String): AccountType =
        runCatching { AccountType.valueOf(value) }.getOrDefault(AccountType.CUSTOM)
}
