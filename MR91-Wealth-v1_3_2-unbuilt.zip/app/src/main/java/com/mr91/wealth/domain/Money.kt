package com.mr91.wealth.domain

import kotlin.math.absoluteValue

/**
 * Every amount in MR91 Wealth is an integer count of TOMAN (تومان).
 * Rials are never converted automatically, decimals are rejected, and floating point is never used for money.
 */
object Money {
    const val UNIT = "تومان"
    const val CURRENCY_CODE = "IRT"
    const val MAX_TOMAN = 1_000_000_000_000_000L // 10^15: keeps sums far away from Long overflow

    private const val MAX_DIGITS = 16
    private val SEPARATORS = Regex("[,\u060C\u066C\\s_\u200C\u200E\u200F]")

    enum class AmountProblem { EMPTY, NOT_NUMERIC, DECIMAL_NOT_ALLOWED, ZERO, NEGATIVE, TOO_LARGE }

    sealed interface Parsed {
        data class Ok(val toman: Long) : Parsed
        data class Invalid(val problem: AmountProblem) : Parsed
    }

    fun parse(raw: String, allowZero: Boolean = false, allowNegative: Boolean = false): Parsed {
        var s = toAsciiDigits(raw.trim()).replace(SEPARATORS, "")
        if (s.isEmpty()) return Parsed.Invalid(AmountProblem.EMPTY)
        var negative = false
        if (s.first() == '-' || s.first() == '\u2212') {
            negative = true
            s = s.substring(1)
        }
        if (s.isEmpty()) return Parsed.Invalid(AmountProblem.NOT_NUMERIC)
        if (s.any { it == '.' || it == '\u066B' }) return Parsed.Invalid(AmountProblem.DECIMAL_NOT_ALLOWED)
        if (s.any { it !in '0'..'9' }) return Parsed.Invalid(AmountProblem.NOT_NUMERIC)
        val digits = s.trimStart('0')
        if (digits.isEmpty()) {
            return if (allowZero) Parsed.Ok(0L) else Parsed.Invalid(AmountProblem.ZERO)
        }
        if (digits.length > MAX_DIGITS) return Parsed.Invalid(AmountProblem.TOO_LARGE)
        val value = digits.toLong()
        if (value > MAX_TOMAN) return Parsed.Invalid(AmountProblem.TOO_LARGE)
        return when {
            !negative -> Parsed.Ok(value)
            allowNegative -> Parsed.Ok(-value)
            else -> Parsed.Invalid(AmountProblem.NEGATIVE)
        }
    }

    fun toAsciiDigits(text: String): String = buildString(text.length) {
        for (c in text) {
            append(
                when (c) {
                    in '\u06F0'..'\u06F9' -> '0' + (c - '\u06F0')
                    in '\u0660'..'\u0669' -> '0' + (c - '\u0660')
                    else -> c
                }
            )
        }
    }

    fun toPersianDigits(text: String): String = buildString(text.length) {
        for (c in text) append(if (c in '0'..'9') '\u06F0' + (c - '0') else c)
    }

    fun format(toman: Long, persianDigits: Boolean): String {
        val grouped = toman.absoluteValue.toString().reversed().chunked(3).joinToString(",").reversed()
        val signed = if (toman < 0) "-$grouped" else grouped
        val shown = if (persianDigits) toPersianDigits(signed) else signed
        return "$shown $UNIT"
    }

    /** Short amount for big numbers, e.g. "۱٫۲ میلیون تومان". Always show the exact value next to it. */
    fun compact(toman: Long, persianDigits: Boolean): String {
        val a = toman.absoluteValue
        val (divisor, name) = when {
            a >= 1_000_000_000_000L -> 1_000_000_000_000L to "تریلیون"
            a >= 1_000_000_000L -> 1_000_000_000L to "میلیارد"
            a >= 1_000_000L -> 1_000_000L to "میلیون"
            a >= 1_000L -> 1_000L to "هزار"
            else -> return format(toman, persianDigits)
        }
        val tenths = a * 10 / divisor
        val whole = tenths / 10
        val fraction = tenths % 10
        val decimal = if (persianDigits) "٫" else "."
        val number = if (fraction == 0L) "$whole" else "$whole$decimal$fraction"
        val signed = (if (toman < 0) "-" else "") + number + " " + name + " " + UNIT
        return if (persianDigits) toPersianDigits(signed) else signed
    }
}
