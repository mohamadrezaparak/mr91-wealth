package com.mr91.wealth.domain

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

data class JalaliDate(val year: Int, val month: Int, val day: Int)

/**
 * Solar Hijri (Jalali) calendar arithmetic. Days are counted as epoch days (days since 1970-01-01)
 * in the Asia/Tehran time zone, so ordering and date ranges never depend on display text.
 */
object JalaliCalendar {
    val TEHRAN: ZoneId = ZoneId.of("Asia/Tehran")
    private const val UNIX_EPOCH_JDN = 2440588L
    private const val MS_PER_DAY = 86_400_000L
    private val BREAKS = longArrayOf(-61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178)
    private val MONTH_NAMES = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")

    fun monthName(month: Int): String = MONTH_NAMES[month - 1]

    private class JalCal(val leap: Long, val gy: Long, val march: Long)

    private fun jalCal(jy: Long): JalCal {
        require(jy >= BREAKS.first() && jy < BREAKS.last()) { "year out of supported range" }
        val gy = jy + 621
        var leapJ = -14L
        var jp = BREAKS[0]
        var jump = 0L
        for (i in 1 until BREAKS.size) {
            val jm = BREAKS[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += (jump / 33) * 8 + (jump % 33) / 4
            jp = jm
        }
        var n = jy - jp
        leapJ += (n / 33) * 8 + ((n % 33) + 3) / 4
        if (jump % 33 == 4L && jump - n == 4L) leapJ += 1
        val leapG = gy / 4 - ((gy / 100 + 1) * 3) / 4 - 150
        val march = 20 + leapJ - leapG
        if (jump - n < 6) n = n - jump + ((jump + 4) / 33) * 33
        var leap = ((n + 1) % 33 - 1) % 4
        if (leap == -1L) leap = 4
        return JalCal(leap, gy, march)
    }

    private fun g2d(gy: Long, gm: Long, gd: Long): Long {
        var d = ((gy + (gm - 8) / 6 + 100100) * 1461) / 4 + (153 * ((gm + 9) % 12) + 2) / 5 + gd - 34840408
        d = d - ((gy + 100100 + (gm - 8) / 6) / 100 * 3) / 4 + 752
        return d
    }

    private fun d2g(jdn: Long): Triple<Long, Long, Long> {
        var j = 4 * jdn + 139361631
        j = j + ((4 * jdn + 183187720) / 146097 * 3) / 4 * 4 - 3908
        val i = ((j % 1461) / 4) * 5 + 308
        val gd = ((i % 153) / 5) + 1
        val gm = ((i / 153) % 12) + 1
        val gy = j / 1461 - 100100 + (8 - gm) / 6
        return Triple(gy, gm, gd)
    }

    private fun d2j(jdn: Long): JalaliDate {
        val gy = d2g(jdn).first
        var jy = gy - 621
        val r = jalCal(jy)
        val jdn1f = g2d(gy, 3, r.march)
        var k = jdn - jdn1f
        if (k >= 0) {
            if (k <= 185) return JalaliDate(jy.toInt(), (1 + k / 31).toInt(), ((k % 31) + 1).toInt())
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1L) k += 1
        }
        return JalaliDate(jy.toInt(), (7 + k / 30).toInt(), ((k % 30) + 1).toInt())
    }

    private fun j2d(jy: Long, jm: Long, jd: Long): Long {
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - (jm / 7) * (jm - 7) + jd - 1
    }

    fun isLeapYear(year: Int): Boolean = jalCal(year.toLong()).leap == 0L

    fun daysInMonth(year: Int, month: Int): Int = when {
        month <= 6 -> 31
        month <= 11 -> 30
        isLeapYear(year) -> 30
        else -> 29
    }

    fun isValid(d: JalaliDate): Boolean =
        d.year in 1300..1500 && d.month in 1..12 && d.day in 1..daysInMonth(d.year, d.month)

    fun fromEpochDay(epochDay: Long): JalaliDate = d2j(epochDay + UNIX_EPOCH_JDN)

    fun toEpochDay(d: JalaliDate): Long {
        require(isValid(d)) { "invalid Jalali date" }
        return j2d(d.year.toLong(), d.month.toLong(), d.day.toLong()) - UNIX_EPOCH_JDN
    }

    /** Parses yyyy/mm/dd (Persian or ASCII digits). Returns null for anything that is not a real date. */
    fun parse(text: String): JalaliDate? {
        val parts = Money.toAsciiDigits(text.trim()).split('/', '-', '.').map { it.trim() }
        if (parts.size != 3) return null
        val y = parts[0].toIntOrNull() ?: return null
        val m = parts[1].toIntOrNull() ?: return null
        val d = parts[2].toIntOrNull() ?: return null
        val date = JalaliDate(y, m, d)
        return if (isValid(date)) date else null
    }

    fun dayOfYear(d: JalaliDate): Int =
        if (d.month <= 6) (d.month - 1) * 31 + d.day else 186 + (d.month - 7) * 30 + d.day

    fun format(epochDay: Long, persianDigits: Boolean): String {
        val d = fromEpochDay(epochDay)
        val text = "${d.year}/${pad2(d.month)}/${pad2(d.day)}"
        return if (persianDigits) Money.toPersianDigits(text) else text
    }

    private fun pad2(n: Int): String = if (n < 10) "0$n" else "$n"

    fun epochDayOf(instantMillis: Long): Long =
        Instant.ofEpochMilli(instantMillis).atZone(TEHRAN).toLocalDate().toEpochDay()

    fun todayEpochDay(nowMillis: Long = System.currentTimeMillis()): Long = epochDayOf(nowMillis)

    /** Epoch millis for a given day. Uses the current time when the day is today, otherwise noon. */
    fun millisForDay(epochDay: Long, nowMillis: Long = System.currentTimeMillis()): Long =
        if (epochDay == epochDayOf(nowMillis)) nowMillis
        else LocalDate.ofEpochDay(epochDay).atTime(12, 0).atZone(TEHRAN).toInstant().toEpochMilli()

    fun dayOfMillis(epochDay: Long): Long = epochDay * MS_PER_DAY
}
