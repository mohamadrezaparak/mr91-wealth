package com.mr91.wealth.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars

enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("خانه", Icons.Filled.Home),
    TRANSACTIONS("تراکنش‌ها", Icons.Filled.ReceiptLong),
    BUDGETS("بودجه", Icons.Filled.PieChart),
    GROUPS("گروه‌ها", Icons.Filled.Groups),
    MORE("بیشتر", Icons.Filled.MoreHoriz),
}

@Composable
fun WealthApp(vm: AppViewModel) {
    var tab by rememberSaveable { mutableStateOf(MainTab.HOME) }
    var accountsOpen by rememberSaveable { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val reduce = rememberReduceMotion()

    // Content starts one centimetre below the status bar and the floating bar sits one centimetre above
    // the system navigation bar, so nothing touches the device edges.
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + ONE_CENTIMETER
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + ONE_CENTIMETER
    val reserve = navBottom + NAV_HEIGHT + 16.dp

    BackHandler(enabled = accountsOpen) { accountsOpen = false }

    LaunchedEffect(vm) {
        vm.messages.collect { msg ->
            val result = snackbar.showSnackbar(
                message = msg.text,
                actionLabel = msg.actionLabel,
                withDismissAction = msg.actionLabel == null,
            )
            if (result == SnackbarResult.ActionPerformed) msg.onAction?.invoke()
        }
    }

    CompositionLocalProvider(LocalBottomReserve provides reserve) {
        Box(Modifier.fillMaxSize()) {
            AnimatedBackdrop()
            Box(Modifier.fillMaxSize().padding(top = statusTop)) {
                if (accountsOpen) {
                    AccountsScreen(vm, onBack = { accountsOpen = false })
                } else {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = {
                            val dir = if (targetState.ordinal > initialState.ordinal) 1 else -1
                            if (reduce) {
                                fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                            } else {
                                (fadeIn(tween(320)) + slideInHorizontally(tween(320)) { it * dir / 5 }) togetherWith
                                    (fadeOut(tween(200)) + slideOutHorizontally(tween(200)) { -it * dir / 5 })
                            }
                        },
                        label = "tabs",
                    ) { current ->
                        when (current) {
                            MainTab.HOME -> HomeScreen(vm)
                            MainTab.TRANSACTIONS -> TransactionsScreen(vm)
                            MainTab.BUDGETS -> BudgetsScreen(vm)
                            MainTab.GROUPS -> GroupsScreen(vm)
                            MainTab.MORE -> MoreScreen(vm, onOpenAccounts = { accountsOpen = true })
                        }
                    }
                }
            }
            if (!accountsOpen) {
                FloatingNavBar(
                    selected = tab,
                    onSelect = { tab = it },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(start = 16.dp, end = 16.dp, bottom = navBottom),
                )
            }
            SnackbarHost(
                hostState = snackbar,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = reserve),
            )
        }
    }
}

@Composable
private fun FloatingNavBar(selected: MainTab, onSelect: (MainTab) -> Unit, modifier: Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(34.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.94f),
        shadowElevation = 14.dp,
        tonalElevation = 2.dp,
    ) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            MainTab.entries.forEach { tab ->
                NavItem(tab, selected == tab) { onSelect(tab) }
            }
        }
    }
}

@Composable
private fun NavItem(tab: MainTab, selected: Boolean, onClick: () -> Unit) {
    val background by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        tween(300),
        label = "navBg",
    )
    val foreground = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = if (selected) 14.dp else 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(tab.icon, contentDescription = tab.label, tint = foreground)
        AnimatedVisibility(
            visible = selected,
            enter = expandHorizontally() + fadeIn(),
            exit = shrinkHorizontally() + fadeOut(),
        ) {
            Text(
                tab.label,
                modifier = Modifier.padding(start = 6.dp),
                color = foreground,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            )
        }
    }
}
