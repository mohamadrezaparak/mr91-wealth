package com.mr91.wealth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mr91.wealth.data.Account
import com.mr91.wealth.data.AccountType
import com.mr91.wealth.domain.Ledger
import com.mr91.wealth.domain.Money

private const val MAX_ACCOUNTS = 30

@Composable
fun AccountsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val accounts by vm.accounts.collectAsState()
    val txs by vm.transactions.collectAsState()
    val reserve = LocalBottomReserve.current
    var editing by remember { mutableStateOf<Account?>(null) }
    var creating by remember { mutableStateOf(false) }
    val balances = Ledger.balances(accounts, txs)

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve + 72.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "back") {
                TextButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("بازگشت")
                }
            }
            item(key = "title") {
                ScreenTitle("حساب‌ها و اهداف", "هر حساب موجودی و در صورت تمایل، هدف پس‌انداز دارد")
            }
            item(key = "total") {
                AppCard(Modifier.staggeredEntrance(1)) {
                    Text("مجموع موجودی حساب‌ها", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    AnimatedMoney(
                        balances.values.sum(),
                        MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    )
                }
            }
            if (accounts.isEmpty()) {
                item(key = "empty") {
                    EmptyState(Icons.Filled.AccountBalanceWallet, "هنوز حسابی ندارید. اولین حساب را اضافه کنید")
                }
            }
            itemsIndexed(accounts, key = { _, a -> a.id }) { i, a ->
                AccountCard(a, balances[a.id] ?: 0L, Modifier.staggeredEntrance(i + 2)) { editing = a }
            }
        }
        if (accounts.size < MAX_ACCOUNTS) {
            ExtendedFloatingActionButton(
                onClick = { creating = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("حساب جدید") },
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = reserve),
            )
        }
    }

    if (creating || editing != null) {
        AccountEditor(initial = editing, vm = vm) {
            creating = false
            editing = null
        }
    }
}

@Composable
private fun AccountCard(a: Account, balance: Long, modifier: Modifier, onClick: () -> Unit) {
    val color = a.colorArgb?.let { Color(it) } ?: colorAt(a.name.hashCode().let { if (it < 0) -it else it })
    val target = a.targetMinor
    AppCard(modifier = modifier, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(color, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(a.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                Text(accountTypeLabel(a.type), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                AnimatedMoney(balance, MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                if (target != null) {
                    Text("هدف: ${money(target)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (target != null && target > 0) {
                val fraction = (balance.toDouble() / target).toFloat().coerceIn(0f, 1f)
                ProgressRing(fraction, color, Modifier.size(84.dp)) {
                    Text(
                        numText((fraction * 100).toLong()) + "٪",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountEditor(initial: Account?, vm: AppViewModel, onDismiss: () -> Unit) {
    val defaultColor = colorAt(0).toArgb().toLong() and 0xFFFFFFFFL
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var type by remember { mutableStateOf(initial?.type ?: AccountType.BANK) }
    var openingText by remember { mutableStateOf(initial?.openingMinor?.toString() ?: "") }
    var targetText by remember { mutableStateOf(initial?.targetMinor?.toString() ?: "") }
    var color by remember { mutableStateOf(initial?.colorArgb ?: defaultColor) }
    val allowNegative = type == AccountType.CREDIT
    val opening: Long? = if (openingText.isBlank()) 0L
    else (Money.parse(openingText, allowZero = true, allowNegative = allowNegative) as? Money.Parsed.Ok)?.toman
    val target: Long? = if (targetText.isBlank()) null
    else (Money.parse(targetText) as? Money.Parsed.Ok)?.toman
    val targetValid = targetText.isBlank() || target != null
    val canSave = name.isNotBlank() && opening != null && targetValid

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text(if (initial == null) "حساب جدید" else "ویرایش حساب", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("نام حساب") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("نوع حساب", style = MaterialTheme.typography.labelLarge)
                ChoiceRow(AccountType.entries, type, ::accountTypeLabel) { type = it }
                OutlinedTextField(
                    value = openingText,
                    onValueChange = { openingText = it },
                    label = { Text("مانده اولیه (تومان)") },
                    singleLine = true,
                    isError = opening == null,
                    supportingText = {
                        Text(if (allowNegative) "برای کارت اعتباری بدهی را منفی وارد کنید" else "عدد صحیح، بدون اعشار")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it },
                    label = { Text("هدف پس‌انداز (اختیاری)") },
                    singleLine = true,
                    isError = !targetValid,
                    supportingText = { Text("اگر خالی بماند، هدفی تعریف نمی‌شود") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("رنگ", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CategoryPalette.forEach { swatch ->
                        val argb = swatch.toArgb().toLong() and 0xFFFFFFFFL
                        val selected = color == argb
                        Box(
                            Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(3.dp, if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent, CircleShape)
                                .padding(4.dp)
                                .background(swatch, CircleShape)
                                .clickable { color = argb },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    vm.saveAccount(initial, name, type, opening ?: 0L, target, color)
                    onDismiss()
                },
                enabled = canSave,
            ) { Text("ذخیره") }
        },
        dismissButton = {
            if (initial != null) {
                TextButton(onClick = {
                    vm.archiveAccount(initial)
                    onDismiss()
                }) { Text("بایگانی", color = MaterialTheme.colorScheme.error) }
            } else {
                TextButton(onClick = onDismiss) { Text("انصراف") }
            }
        },
    )
}

fun accountTypeLabel(type: AccountType): String = when (type) {
    AccountType.CASH -> "نقد"
    AccountType.BANK -> "حساب بانکی"
    AccountType.SAVINGS -> "پس‌انداز"
    AccountType.CREDIT -> "کارت اعتباری"
    AccountType.CUSTOM -> "سفارشی"
}
