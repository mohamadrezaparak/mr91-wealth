package com.mr91.wealth.data

import androidx.room.withTransaction

/**
 * Single entry point for persistence. Every multi-row write runs inside one Room transaction,
 * so a failure halfway through never leaves partial data behind.
 */
class WealthRepository(private val db: WealthDb) {
    private val accountDao = db.accounts()
    private val categoryDao = db.categories()
    private val txDao = db.transactions()
    private val budgetDao = db.budgets()
    private val groupDao = db.groups()
    private val backupDao = db.backup()

    val accounts = accountDao.observe()
    val categories = categoryDao.observe()
    val transactions = txDao.observeActive()
    val budgets = budgetDao.observe()
    val groups = groupDao.observeGroups()
    val members = groupDao.observeMembers()
    val expenses = groupDao.observeExpenses()
    val shares = groupDao.observeShares()
    val settlements = groupDao.observeSettlements()

    suspend fun seedIfEmpty() {
        if (accountDao.count() > 0) return
        db.withTransaction {
            accountDao.upsert(Account("cash", "نقد", AccountType.CASH))
            accountDao.upsert(Account("bank", "بانک", AccountType.BANK))
            listOf(
                Category("food", "خوراک", false),
                Category("transport", "حمل‌ونقل", false),
                Category("bills", "قبوض و اجاره", false),
                Category("shopping", "خرید", false),
                Category("other-expense", "سایر هزینه‌ها", false),
                Category("salary", "حقوق", true),
                Category("other-income", "سایر درآمدها", true),
            ).forEach { categoryDao.upsert(it) }
        }
    }

    suspend fun saveAccount(a: Account) = accountDao.upsert(a)
    suspend fun saveTransaction(t: Transaction) = txDao.upsert(t)
    suspend fun softDeleteTransaction(id: String, now: Long) = txDao.markDeleted(id, now)
    suspend fun restoreTransaction(id: String, now: Long) = txDao.restore(id, now)

    suspend fun upsertBudget(b: Budget) = budgetDao.upsert(b)
    suspend fun deleteBudget(id: String) = budgetDao.delete(id)

    suspend fun createGroup(group: ExpenseGroup) = groupDao.upsertGroup(group)
    suspend fun addMember(member: GroupMember) = groupDao.upsertMember(member)

    suspend fun addSharedExpense(expense: SharedExpense, shares: List<ExpenseShare>) = db.withTransaction {
        groupDao.upsertExpense(expense)
        groupDao.upsertShares(shares)
    }

    suspend fun softDeleteSharedExpense(id: String, now: Long) = groupDao.markExpenseDeleted(id, now)
    suspend fun restoreSharedExpense(id: String) = groupDao.restoreExpense(id)
    suspend fun addSettlement(s: Settlement) = groupDao.upsertSettlement(s)

    suspend fun deleteGroup(groupId: String) = db.withTransaction {
        groupDao.deleteSharesOfGroup(groupId)
        groupDao.deleteExpensesOfGroup(groupId)
        groupDao.deleteSettlementsOfGroup(groupId)
        groupDao.deleteMembersOfGroup(groupId)
        groupDao.deleteGroup(groupId)
    }

    suspend fun snapshot(): BackupSnapshot = db.withTransaction {
        BackupSnapshot(
            accounts = accountDao.all(),
            categories = categoryDao.all(),
            transactions = txDao.all(),
            budgets = budgetDao.all(),
            groups = groupDao.allGroups(),
            members = groupDao.allMembers(),
            expenses = groupDao.allExpenses(),
            shares = groupDao.allShares(),
            settlements = groupDao.allSettlements(),
        )
    }

    /** Replaces all data. Called only with an already validated snapshot; any failure rolls everything back. */
    suspend fun restore(s: BackupSnapshot) = db.withTransaction {
        backupDao.clearShares()
        backupDao.clearExpenses()
        backupDao.clearSettlements()
        backupDao.clearMembers()
        backupDao.clearGroups()
        backupDao.clearTransactions()
        backupDao.clearBudgets()
        backupDao.clearCategories()
        backupDao.clearAccounts()
        backupDao.insertAccounts(s.accounts)
        backupDao.insertCategories(s.categories)
        backupDao.insertTransactions(s.transactions)
        backupDao.insertBudgets(s.budgets)
        backupDao.insertGroups(s.groups)
        backupDao.insertMembers(s.members)
        backupDao.insertExpenses(s.expenses)
        backupDao.insertShares(s.shares)
        backupDao.insertSettlements(s.settlements)
    }
}
