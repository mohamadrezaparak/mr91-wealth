package com.mr91.wealth.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mr91.wealth.data.*
import com.mr91.wealth.domain.*
import com.mr91.wealth.ui.theme.LocalMR91Colors

@Composable
fun GroupsScreen(vm: AppViewModel) {
    val groups by vm.groups.collectAsState()
    val members by vm.members.collectAsState()
    val reserve = LocalBottomReserve.current
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    BackHandler(enabled = selectedId != null) { selectedId = null }

    val selected = selectedId
    if (selected != null) {
        GroupDetail(vm, selected, onBack = { selectedId = null })
        return
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve + 72.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "title") {
                ScreenTitle("دنگ‌ودونگ", "هزینه‌های گروهی، سهم هر نفر و تسویه")
            }
            if (groups.isEmpty()) {
                item(key = "empty") {
                    EmptyState(Icons.Filled.Groups, "هنوز گروهی نساخته‌اید؛ برای سفر یا خانه یک گروه بسازید")
                }
            }
            itemsIndexed(groups, key = { _, g -> g.id }) { i, g ->
                val count = members.count { it.groupId == g.id }
                AppCard(Modifier.staggeredEntrance(i), onClick = { selectedId = g.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(g.name, colorAt(i))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(g.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${numText(count.toLong())} عضو",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("گروه جدید") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = reserve),
        )
    }

    if (creating) {
        TextInputDialog(
            title = "گروه جدید",
            label = "نام گروه (مثلاً سفر شمال)",
            onDismiss = { creating = false },
            onConfirm = { name ->
                vm.createGroup(name)
                creating = false
            },
        )
    }
}

@Composable
fun GroupDetail(vm: AppViewModel, groupId: String, onBack: () -> Unit) {
    val groups by vm.groups.collectAsState()
    val allMembers by vm.members.collectAsState()
    val allExpenses by vm.expenses.collectAsState()
    val allShares by vm.shares.collectAsState()
    val allSettlements by vm.settlements.collectAsState()
    val reserve = LocalBottomReserve.current
    val colors = LocalMR91Colors.current

    val group = groups.firstOrNull { it.id == groupId }
    if (group == null) {
        EmptyState(Icons.Filled.Groups, "این گروه دیگر وجود ندارد")
        return
    }
    val members = allMembers.filter { it.groupId == groupId }
    val memberIds = members.map { it.id }
    val nameOf = members.associate { it.id to it.name }
    val expenses = allExpenses.filter { it.groupId == groupId }
    val expenseIds = expenses.map { it.id }.toSet()
    val shares = allShares.filter { it.expenseId in expenseIds }
    val settlements = allSettlements.filter { it.groupId == groupId }
    val net = Ledger.netBalances(
        memberIds,
        expenses.map { ExpenseFact(it.id, it.payerId, it.amountMinor) },
        shares.map { ShareFact(it.expenseId, it.memberId, it.amountMinor) },
        settlements.map { SettlementFact(it.fromMemberId, it.toMemberId, it.amountMinor) },
    )
    val plan = Ledger.settlementPlan(net)

    var showExpense by remember { mutableStateOf(false) }
    var showMember by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = reserve + 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "back") { TextButton(onClick = onBack) { Text("بازگشت") } }
            item(key = "title") {
                ScreenTitle(group.name, "${numText(members.size.toLong())} نفر · ${numText(expenses.size.toLong())} هزینه ثبت‌شده")
            }
            item(key = "plan") {
                AppCard(Modifier.staggeredEntrance(1)) {
                    SectionHeader("چه کسی به چه کسی بدهکار است")
                    if (plan.isEmpty()) {
                        Text("همه حساب‌ها صاف است ✓", color = colors.income)
                    }
                    plan.forEach { tr ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${nameOf[tr.fromId].orEmpty()} ← ${nameOf[tr.toId].orEmpty()}", fontWeight = FontWeight.Medium)
                                Text(money(tr.amountToman), color = colors.expense, style = MaterialTheme.typography.bodyMedium)
                            }
                            Button(onClick = { vm.recordSettlement(groupId, tr.fromId, tr.toId, tr.amountToman) }) {
                                Text("پرداخت شد")
                            }
                        }
                    }
                }
            }
            item(key = "balances") {
                AppCard(Modifier.staggeredEntrance(2)) {
                    SectionHeader("وضعیت هر نفر")
                    members.forEach { m ->
                        val v = net[m.id] ?: 0L
                        val status = when {
                            v > 0 -> "طلبکار ${money(v)}"
                            v < 0 -> "بدهکار ${money(-v)}"
                            else -> "تسویه"
                        }
                        val tint = when {
                            v > 0 -> colors.income
                            v < 0 -> colors.expense
                            else -> Color.Unspecified
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Avatar(m.name, colorAt(members.indexOf(m)), size = 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(m.name, modifier = Modifier.weight(1f))
                            Text(status, color = tint, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            item(key = "members") {
                AppCard(Modifier.staggeredEntrance(3)) {
                    SectionHeader("اعضا")
                    Text(
                        members.joinToString("، ") { it.name }.ifBlank { "هنوز عضوی اضافه نشده" },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    OutlinedButton(onClick = { showMember = true }) { Text("افزودن نفر") }
                }
            }
            item(key = "addExpense") {
                Button(
                    onClick = { showExpense = true },
                    enabled = members.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().staggeredEntrance(4),
                ) {
                    Icon(Icons.Filled.ReceiptLong, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("ثبت هزینه گروهی")
                }
            }
            item(key = "expensesHeader") { SectionHeader("هزینه‌ها") }
            if (expenses.isEmpty()) {
                item(key = "noExpenses") {
                    Text("هنوز هزینه‌ای ثبت نشده است", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(expenses, key = { it.id }) { e ->
                AppCard(Modifier.animateItem()) {
                    Text(e.title, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${money(e.amountMinor)} · پرداخت‌کننده: ${nameOf[e.payerId].orEmpty()} · " +
                            JalaliCalendar.format(JalaliCalendar.epochDayOf(e.occurredAt), LocalPersianDigits.current),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    TextButton(onClick = { vm.deleteSharedExpense(e.id) }, modifier = Modifier.align(Alignment.End)) {
                        Text("حذف", color = colors.expense)
                    }
                }
            }
            item(key = "deleteGroup") {
                TextButton(onClick = { confirmDelete = true }) {
                    Text("حذف کامل این گروه", color = colors.expense)
                }
            }
        }
    }

    if (showMember) {
        TextInputDialog(
            title = "عضو جدید",
            label = "نام",
            onDismiss = { showMember = false },
            onConfirm = { name ->
                vm.addMember(groupId, name)
                showMember = false
            },
        )
    }

    if (showExpense) {
        SharedExpenseDialog(
            members = members,
            onDismiss = { showExpense = false },
            onSave = { title, amount, payerId, participants ->
                vm.addSharedExpense(groupId, title, amount, payerId, participants)
                showExpense = false
            },
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            shape = MaterialTheme.shapes.extraLarge,
            title = { Text("حذف گروه؟") },
            text = { Text("همه اعضا، هزینه‌ها و تسویه‌های این گروه پاک می‌شوند. این کار قابل برگشت نیست.") },
            confirmButton = {
                Button(onClick = {
                    vm.deleteGroup(groupId)
                    confirmDelete = false
                    onBack()
                }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("انصراف") } },
        )
    }
}

@Composable
fun SharedExpenseDialog(
    members: List<GroupMember>,
    onDismiss: () -> Unit,
    onSave: (String, Long, String, List<String>) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var payerId by remember { mutableStateOf(members.firstOrNull()?.id ?: "") }
    var included by remember { mutableStateOf(members.map { it.id }.toSet()) }

    val amount = (Money.parse(amountText) as? Money.Parsed.Ok)?.toman
    val participants = members.map { it.id }.filter { it in included }
    val preview = if (amount != null && participants.isNotEmpty()) {
        Ledger.splitEqual(amount, participants.size).distinct().joinToString(" و ") { money(it) }
    } else {
        null
    }
    val canSave = amount != null && title.isNotBlank() && participants.isNotEmpty() && payerId.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text("هزینه گروهی", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it }, label = { Text("عنوان") },
                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = amountText, onValueChange = { amountText = it }, label = { Text("مبلغ کل (تومان)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    isError = amountText.isNotBlank() && amount == null,
                    supportingText = { Text(amount?.let { money(it) } ?: "عدد صحیح و مثبت") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("پرداخت‌کننده", style = MaterialTheme.typography.labelLarge)
                ChoiceRow(members, members.firstOrNull { it.id == payerId }, { it.name }) { payerId = it.id }
                Text("سهیم‌ها", style = MaterialTheme.typography.labelLarge)
                members.forEach { m ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = m.id in included,
                            onCheckedChange = { checked ->
                                included = if (checked) included + m.id else included - m.id
                            },
                        )
                        Text(m.name)
                    }
                }
                preview?.let { Text("سهم هر نفر: $it", color = MaterialTheme.colorScheme.primary) }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(title.trim(), amount ?: 0L, payerId, participants) },
                enabled = canSave,
            ) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
fun TextInputDialog(title: String, label: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = MaterialTheme.shapes.extraLarge,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, label = { Text(label) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(text.trim()) }, enabled = text.isNotBlank()) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
