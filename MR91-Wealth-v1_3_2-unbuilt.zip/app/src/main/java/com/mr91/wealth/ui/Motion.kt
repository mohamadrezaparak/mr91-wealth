package com.mr91.wealth.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mr91.wealth.domain.Money
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

/** Android: 160 dp is one inch, so one centimetre is 160 / 2.54 dp on any device. */
val ONE_CENTIMETER: Dp = (160f / 2.54f).dp

/** Height of the floating navigation bar, not counting the gap above the system navigation bar. */
val NAV_HEIGHT: Dp = 68.dp

/** True when the user turned animations off in system settings (Developer options / Remove animations). */
@Composable
fun rememberReduceMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        android.provider.Settings.Global.getFloat(
            context.contentResolver,
            android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
            1f,
        ) == 0f
    }
}

/** Fades and lifts an item in, with a short stagger so lists settle in one after another. */
fun Modifier.staggeredEntrance(index: Int): Modifier = composed {
    val reduce = rememberReduceMotion()
    val progress = remember { Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!reduce) {
            delay(minOf(index, 10) * 55L)
            progress.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
        }
    }
    graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 36.dp.toPx()
    }
}

/** Gentle shrink while pressed. Uses a spring so it feels physical. */
fun Modifier.pressScale(source: MutableInteractionSource): Modifier = composed {
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Counts up to [target]. Intermediate frames are animation only; the last frame is exactly [target].
 * Integer math is used throughout, so no floating-point rounding can leak into the final amount.
 */
@Composable
fun AnimatedMoney(target: Long, style: TextStyle, modifier: Modifier = Modifier) {
    val reduce = rememberReduceMotion()
    val digits = LocalPersianDigits.current
    // A fresh animation per target: it starts at the previously settled value and counts to the new one.
    val progress = remember(target) { Animatable(if (reduce) 1f else 0f) }
    var settled by remember { mutableStateOf(0L) }
    LaunchedEffect(target) {
        if (!reduce) progress.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        settled = target
    }
    val value = if (progress.value >= 1f) target else settled + ((target - settled).toDouble() * progress.value).toLong()
    Text(Money.format(value, digits), style = style, modifier = modifier)
}

/** Slow drifting colour blobs behind every screen. Pure decoration; it never touches content. */
@Composable
fun AnimatedBackdrop(modifier: Modifier = Modifier) {
    val reduce = rememberReduceMotion()
    val transition = rememberInfiniteTransition(label = "backdrop")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(22_000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    val background = MaterialTheme.colorScheme.background
    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val phase = if (reduce) 0.0 else t * 2 * Math.PI
    Box(modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(background)
            val w = size.width
            val h = size.height
            blob(Offset(w * (0.2f + 0.08f * sin(phase).toFloat()), h * (0.18f + 0.05f * cos(phase).toFloat())), w * 0.75f, accent.copy(alpha = 0.22f))
            blob(Offset(w * (0.85f + 0.06f * cos(phase * 0.7).toFloat()), h * (0.55f + 0.06f * sin(phase * 0.7).toFloat())), w * 0.65f, secondary.copy(alpha = 0.16f))
            blob(Offset(w * (0.4f + 0.1f * sin(phase * 0.5).toFloat()), h * (0.9f + 0.04f * cos(phase).toFloat())), w * 0.6f, accent.copy(alpha = 0.12f))
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.blob(center: Offset, radius: Float, color: Color) {
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
        radius = radius,
        center = center,
    )
}
