package com.mr91.wealth.ui.theme

import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** Brand colours sampled from the official MR91 Wealth logo. Do not change without updating brand/tokens.json. */
val BrandNavy = Color(0xFF011D4C)
val BrandCyan = Color(0xFF02C3F9)
val BrandInkOnDark = Color(0xFFEAF6F5)

/** The MR91 mark, traced from the logo. The navy body follows the theme; the cyan bar is always cyan. */
private fun buildMark(body: Color): ImageVector = ImageVector.Builder(
    name = "MR91Mark",
    defaultWidth = 64.dp,
    defaultHeight = 40.dp,
    viewportWidth = 64f,
    viewportHeight = 40f,
).apply {
    path(fill = SolidColor(body), pathFillType = PathFillType.EvenOdd) {
        moveTo(34.47f, 0.13f)
        lineTo(34.2f, 0f)
        lineTo(17.5f, 17.5f)
        lineTo(16.97f, 17.5f)
        lineTo(5.48f, 5.34f)
        lineTo(0f, 0.13f)
        lineTo(0f, 39.95f)
        lineTo(6.68f, 33f)
        lineTo(6.81f, 17.64f)
        lineTo(7.35f, 17.77f)
        lineTo(17.37f, 28.19f)
        lineTo(26.86f, 17.9f)
        lineTo(27.52f, 17.5f)
        lineTo(27.79f, 18.3f)
        lineTo(27.79f, 39.01f)
        lineTo(34.34f, 38.88f)
        close()
        moveTo(37.14f, 0f)
        lineTo(37.14f, 6.55f)
        lineTo(50.1f, 6.68f)
        lineTo(52.51f, 7.08f)
        lineTo(55.05f, 9.09f)
        lineTo(55.85f, 10.69f)
        lineTo(56.25f, 12.43f)
        lineTo(56.25f, 13.9f)
        lineTo(55.58f, 15.77f)
        lineTo(54.78f, 16.97f)
        lineTo(51.97f, 18.71f)
        lineTo(37.14f, 18.71f)
        lineTo(37.14f, 25.12f)
        lineTo(44.09f, 25.25f)
        lineTo(55.18f, 39.82f)
        lineTo(64f, 39.95f)
        lineTo(60.66f, 35.27f)
        lineTo(59.99f, 34.74f)
        lineTo(52.91f, 25.52f)
        lineTo(53.31f, 24.99f)
        lineTo(54.11f, 24.99f)
        lineTo(56.65f, 24.18f)
        lineTo(59.46f, 22.31f)
        lineTo(61.33f, 20.04f)
        lineTo(62.66f, 17.24f)
        lineTo(63.33f, 13.9f)
        lineTo(63.2f, 10.69f)
        lineTo(62.13f, 7.22f)
        lineTo(60.66f, 4.81f)
        lineTo(59.06f, 3.07f)
        lineTo(57.05f, 1.6f)
        lineTo(54.78f, 0.53f)
        lineTo(52.78f, 0f)
        close()
    }
    path(fill = SolidColor(BrandCyan)) {
        moveTo(37.14f, 25.12f)
        lineTo(53.18f, 25.12f)
        lineTo(55.18f, 24.72f)
        lineTo(57.19f, 23.92f)
        lineTo(59.46f, 22.31f)
        lineTo(61.06f, 20.44f)
        lineTo(62f, 18.71f)
        lineTo(37.14f, 18.71f)
        close()
    }
}.build()

@Composable
fun BrandMark(modifier: Modifier = Modifier) {
    val body = if (MaterialTheme.colorScheme.background.luminance() < 0.5f) BrandInkOnDark else BrandNavy
    val mark = remember(body) { buildMark(body) }
    Icon(mark, contentDescription = "نشان MR91", modifier = modifier, tint = Color.Unspecified)
}
