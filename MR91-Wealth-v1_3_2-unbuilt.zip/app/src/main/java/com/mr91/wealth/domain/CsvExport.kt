package com.mr91.wealth.domain

import com.mr91.wealth.data.Transaction
import com.mr91.wealth.data.TxType

/** CSV for spreadsheets. Starts with a UTF-8 BOM so Excel shows Persian text correctly. */
object CsvExport {
    const val BOM = "\uFEFF"
    private const val HEADER = "تاریخ,نوع,مبلغ (تومان),حساب,حساب مقصد,دسته‌بندی,شرح"

    fun encode(txs: List<Transaction>, accountName: (String) -> String, categoryName: (String?) -> String): String {
        val out = StringBuilder(BOM).append(HEADER).append("\r\n")
        txs.sortedBy { it.occurredAt }.forEach { t ->
            val row = listOf(
                JalaliCalendar.format(JalaliCalendar.epochDayOf(t.occurredAt), persianDigits = false),
                typeName(t.type),
                t.amountMinor.toString(),
                accountName(t.accountId),
                t.linkedAccountId?.let(accountName) ?: "",
                categoryName(t.categoryId),
                t.description,
            )
            out.append(row.joinToString(",") { escape(it) }).append("\r\n")
        }
        return out.toString()
    }

    /** Quotes every field and neutralises spreadsheet formulas such as =SUM(...) by prefixing an apostrophe. */
    fun escape(value: String): String {
        val safe = if (value.isNotEmpty() && value[0] in "=+-@\t\r") "'$value" else value
        return "\"" + safe.replace("\"", "\"\"") + "\""
    }

    private fun typeName(type: TxType): String = when (type.canonical()) {
        TxType.INCOME -> "درآمد"
        TxType.TRANSFER -> "انتقال"
        else -> "هزینه"
    }
}
