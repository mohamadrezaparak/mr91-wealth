package com.mr91.wealth

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.mr91.wealth.ui.AppViewModel
import com.mr91.wealth.ui.LocalPersianDigits
import com.mr91.wealth.ui.ThemeMode
import com.mr91.wealth.ui.WealthApp
import com.mr91.wealth.ui.theme.MR91Theme

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels { AppViewModel.Factory(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settings by vm.settings.collectAsState()
            val dark = when (settings.theme) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalPersianDigits provides settings.persianDigits,
            ) {
                MR91Theme(darkTheme = dark, accent = settings.accent, dynamicColor = settings.dynamicColor) { WealthApp(vm) }
            }
        }
    }
}
