package com.mr91.wealth.domain

import com.mr91.wealth.data.Account
import com.mr91.wealth.data.Budget
import com.mr91.wealth.data.Transaction
import com.mr91.wealth.data.TxType

data class Totals(val balanceToman: Long, val incomeToman: Long, val expenseToman: Long) {
    val netToman: Long get() = incomeToman - expenseToman
}

enum class BudgetState { ON_TRACK, WARNING, REACHED, OVERSPENT }

data class BudgetProgress(val spentToman: Long, val limitToman: Long, val percent: Int, val state: BudgetState) {
    val remainingToman: Long get() = limitToman - spentToman
}

data class Transfer(val fromId: String, val toId: String, val amountToman: Long)
data class ExpenseFact(val id: String, val payerId: String, val amountToman: Long)
data class ShareFact(val expenseId: String, val memberId: String, val amountToman: Long)
data class SettlementFact(val fromId: String, val toId: String, val amountToman: Long)

/**
 * Pure accounting rules. No Android types, no floating point.
 * Account balance = opening balance + signed movements, so the balance is always derived from the ledger.
 */
object Ledger {

    fun effectOnAccount(t: Transaction, accountId: String): Long {
        var delta = 0L
        if (t.accountId == accountId) {
            delta += when (t.type.canonical()) {
                TxType.INCOME -> t.amountMinor
                else -> -t.amountMinor
            }
        }
        if (t.type.canonical() == TxType.TRANSFER && t.linkedAccountId == accountId) {
            delta += t.amountMinor
        }
        return delta
    }

    fun balances(accounts: List<Account>, txs: List<Transaction>): Map<String, Long> =
        accounts.associate { a -> a.id to (a.openingMinor + txs.sumOf { effectOnAccount(it, a.id) }) }

    /** Income and expense inside [range]. Transfers are never income or expense. */
    fun flow(txs: List<Transaction>, range: DayRange?): Pair<Long, Long> {
        var income = 0L
        var expense = 0L
        for (t in txs) {
            if (range != null && JalaliCalendar.epochDayOf(t.occurredAt) !in range) continue
            when (t.type.canonical()) {
                TxType.INCOME -> income += t.amountMinor
                TxType.EXPENSE -> expense += t.amountMinor
                else -> Unit
            }
        }
        return income to expense
    }

    fun totals(accounts: List<Account>, txs: List<Transaction>, range: DayRange? = null): Totals {
        val (income, expense) = flow(txs, range)
        return Totals(balances(accounts, txs).values.sum(), income, expense)
    }

    /** Spending against a budget: expenses in the budget's category (or all expenses) inside its period. */
    fun spentFor(budget: Budget, txs: List<Transaction>): Long =
        txs.asSequence()
            .filter { it.type.canonical() == TxType.EXPENSE }
            .filter { budget.categoryId == null || it.categoryId == budget.categoryId }
            .filter { JalaliCalendar.epochDayOf(it.occurredAt) in DayRange(budget.startEpochDay, budget.endEpochDay) }
            .sumOf { it.amountMinor }

    fun progress(limitToman: Long, spentToman: Long): BudgetProgress {
        require(limitToman > 0) { "limit must be positive" }
        require(spentToman >= 0) { "spent must not be negative" }
        // Capped before multiplying so the integer math can never overflow.
        val percent = if (spentToman >= limitToman * 10) 1000 else (spentToman * 100 / limitToman).toInt()
        val state = when {
            spentToman > limitToman -> BudgetState.OVERSPENT
            spentToman == limitToman -> BudgetState.REACHED
            percent >= 80 -> BudgetState.WARNING
            else -> BudgetState.ON_TRACK
        }
        return BudgetProgress(spentToman, limitToman, percent, state)
    }

    /** Equal split. The remainder is distributed one toman at a time to the first people, so the parts always sum to the total. */
    fun splitEqual(totalToman: Long, people: Int): List<Long> {
        require(people > 0) { "need at least one person" }
        require(totalToman >= 0) { "total must not be negative" }
        val base = totalToman / people
        val remainder = (totalToman % people).toInt()
        return List(people) { index -> base + if (index < remainder) 1L else 0L }
    }

    /** Net position per member: positive = is owed money, negative = owes money. Sums to zero. */
    fun netBalances(
        memberIds: List<String>,
        expenses: List<ExpenseFact>,
        shares: List<ShareFact>,
        settlements: List<SettlementFact>,
    ): Map<String, Long> {
        val net = LinkedHashMap<String, Long>()
        memberIds.forEach { net[it] = 0L }
        fun bump(id: String, delta: Long) { net[id] = (net[id] ?: 0L) + delta }
        expenses.forEach { bump(it.payerId, it.amountToman) }
        shares.forEach { bump(it.memberId, -it.amountToman) }
        // Paying someone back reduces what you owe and what they are owed.
        settlements.forEach {
            bump(it.fromId, it.amountToman)
            bump(it.toId, -it.amountToman)
        }
        return net
    }

    /** Minimum-ish set of transfers that clears every balance (greedy, largest first, deterministic). */
    fun settlementPlan(net: Map<String, Long>): List<Transfer> {
        // Balances always sum to zero for consistent data. If they do not, return no plan instead of crashing the UI.
        if (net.values.sum() != 0L) return emptyList()
        val order = compareByDescending<Pair<String, Long>> { it.second }.thenBy { it.first }
        val debtors = net.filterValues { it < 0 }.map { it.key to -it.value }.sortedWith(order).toMutableList()
        val creditors = net.filterValues { it > 0 }.map { it.key to it.value }.sortedWith(order).toMutableList()
        val plan = mutableListOf<Transfer>()
        var i = 0
        var j = 0
        while (i < debtors.size && j < creditors.size) {
            val (debtorId, debt) = debtors[i]
            val (creditorId, credit) = creditors[j]
            val pay = minOf(debt, credit)
            plan += Transfer(debtorId, creditorId, pay)
            debtors[i] = debtorId to (debt - pay)
            creditors[j] = creditorId to (credit - pay)
            if (debtors[i].second == 0L) i++
            if (creditors[j].second == 0L) j++
        }
        return plan
    }

    /** Expense totals per category inside [range], largest first. A null key means "no category". */
    fun expenseByCategory(txs: List<Transaction>, range: DayRange?): List<Pair<String?, Long>> =
        txs.asSequence()
            .filter { it.type.canonical() == TxType.EXPENSE }
            .filter { range == null || JalaliCalendar.epochDayOf(it.occurredAt) in range }
            .groupingBy { it.categoryId }
            .fold(0L) { acc, t -> acc + t.amountMinor }
            .entries
            .map { it.key to it.value }
            .sortedByDescending { it.second }
}
