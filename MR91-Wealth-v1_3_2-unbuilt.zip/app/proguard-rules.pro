# Room generates its own keep rules. Add app-specific rules here only when minification is enabled.
